//
//  AppDelegate.h
//  countDownDemo
//
//  Created by 孔凡列 on 15/12/8.
//  Copyright © 2015年 czebd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

