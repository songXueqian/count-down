//
//  CountDownCell.m
//  倒计时
//
//  Created by Maker on 16/7/6.
//  Copyright © 2016年 郑文明. All rights reserved.
//

#import "CountDownCell.h"

@implementation CountDownCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
