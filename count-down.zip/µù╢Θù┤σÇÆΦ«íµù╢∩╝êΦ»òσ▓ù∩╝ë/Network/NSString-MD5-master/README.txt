The method names are self-explanatory... ;-)
License: released into the pulic domain, except that THERE'S NO WARRANTY AT ALL, and I'm
not responsible for any damage connected to the use of this software. Usable within the limits of applicable law
(so nothing criminal, cracking, patching, hacking please!).

