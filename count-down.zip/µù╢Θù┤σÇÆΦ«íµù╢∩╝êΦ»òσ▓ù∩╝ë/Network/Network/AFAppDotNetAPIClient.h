// AFAppDotNetAPIClient.h
// Copyright (c) 2012 Mattt Thompson (http://mattt.me/)
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

//注：
//1，所有的返参默认为string类型；其它类型会另行标注；（除了string，还需要使用int类型）
//2，所有的入参，均不限类型；
//3，所有的id参数，按照int传递；
//4，所有的返回值ret，按照int传递；
//5，所有的返参中，涉及数量的，按照int传递

#import <Foundation/Foundation.h>


#import "AFHTTPSessionManager.h"
//#import "LoginModel.h"

////////////////////////////////
////////////////////////////////

//Jason 20150629
//打开注释，测试环境193服务器
//注释掉，生产环境218服务器

#define TARGET_TEST_SERVER     1

//Jason 20150629
//打开注释，打开版本更新，发布企业版本
//注释掉，关闭版本更新，发布applestore

#define AppleStore 1

////////////////////////////////////////////////////////////////

typedef enum : NSUInteger {
    eJsonDefault,
    eJsonNil,
    eJsonNull,
    eJsonNotDictionary
} CustomErrorFailed;

typedef enum : NSUInteger {
    ApiStatusSuccess,
    ApiStatusFail,
    ApiStatusError,
    ApiStatusException,
    ApiStatusNetworkNotReachable,
    ApiStatusAppNoUse
} ApiStatus;

#define appCurVersion [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]

#define appCurVersionNum [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"]

#define JsonErrorDomain @"com.Houses.json"

#define DownloadPath @"Download"

#define PortalURL @"http://58.215.78.118/1709/ip.txt"

//开发：101.200.181.193
//生产：101.200.158.218
#if TARGET_TEST_SERVER
    //测试环境地址
    #define BASE_URL @"http://101.200.181.193"

#else
    //生产环境地
//      #define BASE_URL @"http://101.200.158.218"
    #define BASE_URL @"http://www.meilaoban.com"

#endif

#define APIName BASE_URL"/transapi/index.php"

#define APIImageName BASE_URL"/"


//Api Value Key
#define ParametersKeyRet @"ret"
#define ParametersKeyMsg @"msg"
#define ParametersKeyFun @"a"
#define ParametersKeyVer @"v"
#define ParametersKeyDat @"dat"
//API Version
//每次更新API接口版本的时候，需要修改该值
#define ApiVersion @"3.03"

#define ServerVersionURL    BASE_URL @"/coalboss/m/coaldriver_version.json"

//Api Name
#define ApiNameSaveChannelId @"common.saveChannelId"//保存推送号
#define ApiNameGetStartAd @"common.getStartAd"//登录广告
#define ApiNameVersion @"common.getNewVersion"//获取最新版本号
#define ApiNameCrumbleInfo @"common.saveUserCrumbleInfo"//记录用户崩溃信息
#define ApiNameSMSCode @"users.getSmsCode"//获取验证码
#define ApiNameRegistUser @"users.registUser"//注册
#define ApiNameLogin @"users.login"//登录
#define ApiNameGetBackPwd @"users.getBackPwd"//找回密码

#define ApiNameGetInfoList @"infomation.getInfoList"//资讯列表
#define ApiNameGetFreightShow @"infomation.getFreightShow"//今日运费
#define ApiNameGetProductShow @"infomation.getProductShow"//今日煤价
#define ApiNameGetBroadcastTraffic @"infomation.getBroadcastTraffic"//路况播报
#define ApiNameGetBroadcastWeather @"infomation.GetBroadcastWeather"//天气播报

#define ApiNameTransportsGetOrdersList @"transports.getOrdersList"//获取资源列表
#define ApiNameTransportsGetSpecialLineList @"transports.getSpecialLineList"//获取专线列表
#define ApiNameGetCarouselPic @"home.getCarouselPic"//首页轮播图
#define ApiNameTransportsGetOrderInfo @"transports.getOrderInfo"//货源详情
#define ApiNameGrabTransport @"transports.grabTransport"//抢单
#define ApiNameGetTransportInfo @"transports.getTransportInfo"//进行中的运单
#define ApiNameCancelTransports @"transports.cancelTransports"//取消运单
#define ApiNameContactOwner @"transports.contactOwner"//联系货主
#define ApiNameGetHisTransportList @"transports.getHisTransportsList"//历史运单
#define ApiNameGetHisTransportInfo @"transports.getHisTransportInfo"//历史运单

#define ApiNameGetRouteList @"route.getRouteList"//订阅路线列表
#define ApiNameGetDistrict @"common.getDistrict"//获取省市县
#define ApiNameAddRoute @"route.addRoute"//添加路线
#define ApiNameDeleteRoute @"route.deleteRoute"//删除路线

#define ApiNameGetBankCardsList @"account.getBankCardsList"//银行卡列表
#define ApiNameAddBankCard @"account.addBankCard"//添加银行卡
#define ApiNameDeleteBankCard @"account.deleteBankCard"//删除银行卡
#define ApiNameCheckBankCardNum @"account.checkBankCardNum"//校验银行卡


#define ApiNameSysmsgList @"message.getSysMsgList"//消息列表
#define ApiNameSysmsgInfo @"message.getSysMsgInfo"//消息详情
#define ApiNameDelMsg @"message.deleteMsg"//删除消息



#define ApiNameCheckInfo @"users.CheckInfo"//身份认证页面(货主 司机通用)
#define ApiNameUploadCheckPhoto @"users.uploadCheckPhoto"//上传图片
#define ApiNameAddCheckInfo @"users.addCheckInfo"//提交审核
#define ApiNameUploadAvatar @"users.uploadAvatar"//上传头像

//#define ApiNameProductList @"product.productList"//煤炭交易
//#define ApiNameShippingAddressDefault @"users.shippingAddressDefault"//默认收货
//
//#define ApiNameAddressAddShow @"users.addressAddShow"//获取归属地
//
//#define ApiNameProductInfo @"product.productInfo"//煤炭详情
//#define ApiNameOrderAdd @"users.orderAdd"//提交订单
//
//#define ApiNameGetProductCategory @"product.getProductCategory"//获取煤炭信息筛选的煤种分类
//#define ApiNameGetProductQnet @"product.getProductQnet"//获取发热量筛选的分类
//
//
//#define ApiNameMyOrdersList @"order.myOrdersList"//我的订单列表
//#define ApiNameOrderInfo @"order.orderInfo"//订单详情
//#define ApiNameOrderDel @"users.orderDel"//取消订单
//#define ApiNameOrderTree @"order.orderTree"//订单树
//#define ApiNameOrderImages @"order.orderImages"//查看单据
//
//#define ApiNameRemoveOrders @"order.removeOrders"//删除订单
//
//#define ApiNameLogisticsList @"logistics.logisticsList"//物流列表
//
//#define ApiNameOrderDoneList @"order.orderDoneList"//一键买煤
//
//#define ApiNameConsumeConfAdd @"stocks.consumeConfAdd"//提交库存配置
//#define ApiNameConsumeHistoryList @"stocks.consumeHistoryList"//消耗历史
//#define ApiNameConsumeHistoryListModify @"stocks.consumeHistoryListModify"//修改消耗历史
//
//
//#define ApiNameClientManager @"users.clientManager"//客户经理
#define ApiNameFeedback @"common.saveFeedBack"//意见反馈
//#define ApiNameShippingAddressList @"users.shippingAddressList"//收货地址列表
//#define ApiNameShippingAddressDel @"users.shippingAddressDel"//删除收货地址
//#define ApiNameDefaultAddress @"users.defaultAddress"//设置默认收货地址
//#define ApiNameShippingAddressInfo @"users.shippingAddressInfo"//收货地址详情
//#define ApiNameShippingAddressAdd @"users.shippingAddressAdd"//添加收货地址
//#define ApiNameShippingAddressModify @"users.shippingAddressModify"//修改收货地址
//
//#define ApiNameTransList @"waybill.waybillList"//运单列表
//#define ApiNameSucceedTransport @"waybill.succeedTransport"//抢单
//#define ApiNameHistoryList @"waybill.waybillHistoryList"//运单历史列表
//#define ApiNameWaybillInfo @"waybill.waybillInfo"//运单历史详情
//
//#define ApiNameTrucksPhoto @"users.trucksPhoto"//上传票据
//#define ApiNameCheckTrucksPhoto @"users.checkTrucksPhoto"//获得票据
//#define ApiNameDelTrucksPhoto @"users.delTrucksPhoto"//删除司机上传图片
//
//
//
//#define ApiNameEvaluateAdd @"logistics.evaluateAdd"//提交评价
//
//

//

//
//#define ApiNameTrucksLocation @"users.trucksLocation"//获取司机坐标
//
//#define ApiNameSendBaiduPushAccount @"common.sendBaiduPushAccount"//百度推送
//
//#define ApiNameAddLocation @"common.addLocation"//司机上传定位
//
//#define ApiNameGetSubCities @"common.getSubCities"//获取省市区
//
//#define ApiNameBankCardList @"users.bankCardList"//银行卡列表
//
//#define ApiNameBindBankCard @"users.bindBankCard"//绑定银行卡
//
//#define ApiNameDelBankCardt @"users.delBankCard"//删除银行卡绑定
//
//#define ApiNameCheckBankCardNum @"users.checkBankCardNum"//银行卡号校验
//
//#define ApiNameTransportList @"order.transportList"//买家查看运单列表(下线付款)
//
//#define ApiNameTransportHistoryList @"order.transportHistoryList"//买家查看运单历史(下线付款)
//
//#define ApiNamePushPurchase @"users.pushPurchase"//司机推送品鉴部
//
//#define ApiNameCommitReceipt @"order.commitReceipt"//买家确定提交票据
//#define ApiNameCheckReceipt @"order.checkReceipt"//买家查看上传票据
//
//#define ApiNameAdAlert @"common.adAlert"//广告通知
//

//#define ApiNameGetTradingVolume @"home.getTradingVolume"//获取交易量
//
//#define ApiNameGetDataList @"dataupdate.getDataList"//单据列表
//#define ApiNameGetDataInfo @"dataupdate.getDataInfo"//单据详情
//#define ApiNameSubmitData @"dataupdate.submitData"//提交单据

#define ApiNameGetUserInfo @"users.getUserInfo"//个人信息
#define ApiNameUploadAvatar @"users.uploadAvatar"//上传头像

#define ApiNamePublishOrder @"orders.publishOrder"//发布货源

#define ApiNameGetAddressList @"address.getAddressList"//装卸地址列表
#define ApiNameAddressInfo @"address.addressInfo"//地址详情

#define ApiNameAddAddress @"address.addAddress"//添加装卸地址
#define ApiNameEditAddress @"address.editAddress"//编辑装卸地址

#define ApiNameDeleteAddress @"address.deleteAddress"//删除装卸地址
#define ApiNameDefaultAddress @"address.defaultAddress"//设置默认地址

#define ApiNameGetOrdersList @"orders.getOrdersList"//货主端运单列表
#define ApiNameGetOrderInfo @"orders.getOrderInfo"//货主端运单详情

#define ApiNameFixDriver @"orders.fixDriver"//确认司机抢单
#define ApiNameCompleteTrans @"orders.completeTrans"//确认运单完成
#define ApiNameCancelOrder @"orders.cancelOrder"//取消货源

#define ApiNameGetRedPointOrderList @"orders.getRedPointOrderList"//货源列表红点

#define ApiNameGetTransList @"orders.getTransList"//获取运单列表
#define ApiNameGetGrabbedLis @"orders.getGrabbedList"//获取抢单列表
#define ApiNameGetTransPhoto @"orders.getTransPhoto"//获取单据
#define ApiNameUploadTransPhoto @"orders.uploadTransPhoto"//上传单据
#define ApiNameDeleteTransPhoto @"orders.deleteTransPhoto"//删除单据

#define ApiNameCancelGrab @"orders.cancelGrab"//取消已抢的单


#define ApiNameAddEleBill @"electronic.addEleBill"//添加电子提煤单
#define ApiNameEleBillList @"electronic.EleBillList"//电子提煤单列表
#define ApiNameEleBillInfo @"electronic.EleBillInfo"//电子提煤单详情
#define ApiNameDoneEleBill @"electronic.doneEleBill"//完成电子提煤单
#define ApiNameUploadPhoto @"electronic.uploadPhoto"//上传图片
#define ApiNameDeletePhoto @"electronic.deletePhoto"//删除图片
#define ApiNameSaveNotes @"electronic.saveNotes"//保存备注

#define ApiNameDelEleBill @"electronic.delEleBill"//删除电子提煤单

#define ApiNameTransEleBill @"electronic.transEleBill"//上游完成-运输中

@interface AFAppDotNetAPIClient :AFHTTPSessionManager
@property (nonatomic, strong) NSString *protalurl;

//@property (nonatomic, strong) LoginModel *login_model;
//@property (nonatomic, strong) ApiMyOrderListModel *MyOrder;

+ (instancetype)sharedClient;

-(void)portal:(void (^)(id result_data, ApiStatus result_status))result;
-(void)uploadFile:(NSString *)function Files:(NSArray *)files Dat:(id)dat Result:(void (^)(id result_data, ApiStatus result_status))result Progress:(void (^)(CGFloat progress))progress;
-(void)downloadFile:(NSString *)function Dat:(id)dat FileName:(NSString *)filename Result:(void (^)(id result_data, ApiStatus result_status))result Progress:(void (^)(CGFloat progress))progress;

-(void)apiPost:(NSString *)function Dat:(id)dat Result:(void (^)(id result_data, ApiStatus result_status, NSString *api))result;

-(void)apiGet:(NSString *)function Dat:(id)dat Result:(void (^)(id result_data, ApiStatus result_status, NSString *api))result;




@end
