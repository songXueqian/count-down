////
////  JSONHelper.h
////  Houses
////
////  Created by Liang Zhang on 14/12/15.
////  Copyright (c) 2014年 bangbangtianxia. All rights reserved.
////
//
#import <Foundation/Foundation.h>
////Model Header File
////#import "SMSCodeModel.h"
//#import "RegistUserModel.h"
//#import "LoginModel.h"
////#import "AudiInfoModel.h"
////#import "CheckAuditImgModel.h"
////#import "CarouselListModel.h"
////#import "CurrentStocksModel.h"
////
//#import "SysmsgListModel.h"
//#import "SysmsgInfoModel.h"
////
////#import "ProductListModel.h"
////#import "ShippingAddressDefaultModel.h"
////#import "ProductInfoModel.h"
////
////
////#import "MyOrdersListModel.h"
////#import "OrderInfoModel.h"
////#import "OrderDoneListModel.h"
////#import "TransInfoModel.h"
////
////#import "ClientManagerModel.h"
////#import "ShippingAddressListModel.h"
////
////#import "WaybillListModel.h"
////#import "HistoryListModel.h"
////
////#import "ConsumeHistoryListModel.h"
////#import "LogisticsListModel.h"
////#import "OrderTreeModel.h"
////
//#import "getStartAdModel.h"
////#import "OrderImagesModel.h"
////#import "CheckTrucksPhotoModel.h"
////
////#import "TrucksLocationModel.h"
////
////#import "subacityModel.h"
////
////#import "CoalKindModel.h"
////#import "CoalHotModel.h"
////
////#import "BankListModel.h"
////#import "CheckBankModel.h"
////
////
////#import "paperModel.h"
////#import "photoModel.h"
////
////#import "transportListModel.h"
////#import "transportHistoryListModel.h"
////
////#import "checkReceiptMopdel.h"
////
////#import "UploadPhotoModel.h"
////#import "TrucksPhotolModel.h"
////
////#import "AdAlertModel.h"
////
////#import "areaModel.h"
////
//#import "AppStoreVersionModel.h"
////
////#import "GetTradingVolumeModel.h"
////
////#import "GetDataListModel.h"
////
////#import "GetDataInfoModel.h"
////
////#import "UploadImgModel.h"
//#import "getOrderListModel.h"
//
//#import "NewsListModel.h"
//#import "TodayShowModel.h"
//#import "TransportsGetOrderListModel.h"
//#import "TransportsGetOrderInfoModel.h"
//#import "getCarouselPicModel.h"
//#import "grabTransportModel.h"
//#import "getTransportInfoModel.h"
//#import "getHisTransportsListModel.h"
//#import "getHisTransportInfoModel.h"
//
//#import "RouteListModel.h"
//#import "subacityModel.h"
//
//#import "getAddressListModel.h"
//#import "addressInfoModel.h"
//
//#import "BankListModel.h"
//#import "CheckBankModel.h"
//
//
//#import "getUserInfoModel.h"
//#import "getOrdersListModel.h"
//#import "getOrderInfo.h"
//#import "transportsModel.h"
//
//#import "checkInfoModel.h"
//#import "checkInfoPapersModel.h"
//
//#import "uploadCheckPhotoModel.h"
//#import "uploadAvatarModel.h"
//#import "getRedPointOrderListModel.h"
//
//#import "getTransListModel.h"
//#import "getGrabbedListModel.h"
//#import "getTransPhotoModel.h"
//#import "uploadTransPhotoModel.h"
//#import "deleteTransPhotoModel.h"
//
//#import "getSpecialLineListModel.h"
//
//#import "uploadPhotoModel.h"
//#import "EleBillInfo.h"
//#import "EleBillListModel.h"
//#import "addEleBillModel.h"
//#import "deleteTransPhotoModel.h"
//#import "uploadTransPhotoModel.h"
//
//#import "billPhoto_inModel.h"
//#import "billPhoto_outModel.h"
//
//
//Api Name
typedef enum : NSUInteger {
    
    
    ApiEnumGetTransList ,//获取运单列表
    ApiEnumGetGrabbedList,//获取抢单列表
    ApiEnumGetTransPhoto,//获取单据
    ApiEnumUploadTransPhoto,//上传单据
    ApiEnumDeleteTransPhoto,//删除单据
    ApiEnumCancelGrab,//取消已抢的单
    
    ApiEnumSaveChannelId ,//保存推送号
    ApiEnumSMSCode,//获取验证码
    ApiEnumRegistUser,//注册
    ApiEnumLogin,//登录
    ApiEnumGetBackPwd,//找回密码
    
    ApiEnumGetInfoList,//资讯列表
    ApiEnumGetFreightShow ,//今日运费
    ApiEnumGetProductShow ,//今日煤价
    ApiEnumGetBroadcastTraffic,//路况播报
    ApiEnumGetBroadcastWeather ,//天气播报
    
    ApiEnumTransportsGetOrdersList ,//获取资源列表
    ApiEnumTransportsGetSpecialLineList ,//获取专线列表
    ApiEnumGetCarouselPic ,//首页轮播图
    ApiEnumTransportsGetOrderInfo ,//货源详情
    ApiEnumGrabTransport ,//抢单
    ApiEnumGetTransportInfo,//进行中的运单
    ApiEnumCancelTransports ,//取消运单
    ApiEnumContactOwner ,//联系货主
    ApiEnumGetHisTransportInfo ,//历史运单详情
    ApiEnumGetHisTransportList ,//历史运单列表
    
    ApiEnumGetRouteList ,//订阅路线列表
    ApiEnumGetDistrict ,//获取省市县
    ApiEnumAddRoute ,//添加路线
    ApiEnumDeleteRoute,//删除路线
    
    
    
     ApiEnumGetBankCardsList ,//银行卡列表
     ApiEnumAddBankCard ,//添加银行卡
     ApiEnumDeleteBankCard ,//删除银行卡
     ApiEnumCheckBankCardNum ,//校验银行
    
    
     ApiEnumCheckInfo ,//身份认证页面(货主 司机通用)

    ApiEnumSysmsgList,//消息列表
    ApiEnumSysmsgInfo,//消息详情
    ApiEnumDelMsg,//删除消息
    
    ApiEnumUploadCheckPhoto ,//上传图片
    ApiEnumAddCheckInfo ,//提交审核
    ApiEnumUploadAvatar ,//上传头像

//    ApiEnumProductList,//煤炭交易
//    ApiEnumShippingAddressDefault,//默认收货
//    ApiEnumProductInfo,//煤炭详情
//    ApiEnumOrderAdd,//提交订单
//    
//    ApiEnumConsumeConfAdd,//提交库存配置
//    ApiEnumConsumeHistoryList,//消耗历史
//    ApiEnumConsumeHistoryListModify,//修改消耗历史
//    
//    
//    
//    ApiEnumMyOrdersList,//我的订单列表
//    ApiEnumOrderInfo,//订单详情
//    ApiEnumOrderDel,//取消订单
//    ApiEnumRemoveOrders,//删除订单
//    ApiEnumOrderTree,//订单树
//    ApiEnumOrderImages,//查看单据
//    
//    
//    ApiEnumOrderDoneList,//一键买煤
//    
//    ApiEnumLogisticsList,//物流列表
//    
//    
//    
//    
//    ApiEnumWaybillList,//运单列表
//    ApiEnumSucceedTranspor,//抢单
//    ApiEnumTrucksPhotol,//上传票据
//    ApiEnumCheckTrucksPhoto,//获得票据
//    ApiEnumDelTrucksPhoto,//删除司机上传图片
//    ApiEnumHistoryList,//运单历史列表
//
//    
//    
//    ApiEnumClientManager,//客户经理
    ApiEnumFeedback,//意见反馈
//    ApiEnumShippingAddressList,//收货地址列表
//    ApiEnumShippingAddressDel,//删除收货地址
//    ApiEnumDefaultAddress,//设置默认收货地址
//    ApiEnumShippingAddressInfo,//收货地址详情
//    ApiEnumShippingAddressAdd,//添加收货地址
//    ApiEnumShippingAddressModify,//修改收货地址
//    
//    
//    ApiEnumSendBaiduPushAccount,//百度推送
//    
    ApiEnumGetStartAd,//登录广告
//
    ApiEnumCrumbleInfo,//记录用户崩溃信息
//
//    ApiEnumEvaluateAdd,//提交评价
//    
//    ApiEnumTrucksLocation,//获取司机坐标
//    ApiEnumAddLocation,//司机上传定位
//    
//    ApiEnumGetSubCities,//获取省市区
//    
//    ApiEnumGetProductCategory,//获取煤炭信息筛选的煤种分类
//    ApiEnumGetProductQnet,//获取发热量筛选的分类
//    
//    ApiEnumGetWaybillInfo, //历史运单详情
//    
//    
//    
//    ApiEnumGetBankCardList,//银行卡列表
//    
//    ApiEnumGetBindBankCard,//绑定银行卡
//    ApiEnumGetDelBankCardt,//删除银行卡绑定
//    
//    ApiEnumGetCheckBankCardNum, //银行卡号校验
//    
//    ApiEnumTransportList, //买家查看运单列表(下线付款)
//    ApiEnumTransportHistoryList,//买家查看运单历史(下线付款)
//    
//    ApiEnumPushPurchase, //司机推送品鉴部
//   
//    ApiEnumCommitReceipt,//买家确定提交票据
//    ApiEnumCheckReceipt,//买家查看上传票据
//    
//    ApiEnumAdAlert,//广告通知
//    
//    ApiEnumAddressAddShow,//获取省市区
//    
    ApiEnumVersion,//获取最新版本信息
//    ApiEnumGetTradingVolume,//获取交易量
//    
//    ApiEnumGetDataList,//单据列表
//    ApiEnumGetDataInfo,//单据详情
//    ApiEnumSubmitData,//提交单据
//    ApiEnumUploadImg,//提交单据图片
    ApiEnumPublishOrder, //发布货源
    ApiEnumGetUserInfo,//个人信息
    ApiEnumGetAddressList,//装卸地址列表
    ApiEnumAddressInfo,//地址详情
    
    ApiEnumAddAddress,//添加装卸地址
    ApiEnumEditAddress,//编辑装卸地址
    ApiEnumDeleteAddress,//删除装卸地址
    ApiEnumDefaultAddress,//设置默认地址
    
    
    ApiEnumGetOrdersList,//货主端运单列表
    
    ApiEnumGetOrderInfo,//货主端运单详情
    
    ApiEnumFixDriver,//确认司机抢单
    ApiEnumCompleteTrans,//确认运单完成
    ApiEnumCancelOrder,//取消货源
    ApiEnumGetRedPointOrderList,//货源列表红点
    
    ApiEnumAddEleBill,//添加电子提煤单
    ApiEnumEleBillList,//电子提煤单列表
    ApiEnumEleBillInfo,//电子提煤单详情
    ApiEnumDoneEleBill,//完成电子提煤单
    ApiEnumUploadPhoto,//上传图片
    ApiEnumDeletePhoto,//删除图片
    ApiEnumSaveNotes,//保存备注
    ApiEnumDelEleBill,//删除电子提煤单
    ApiEnumTransEleBill,//上游完成-运输中
    
    
    
    ApiEnumNone,
} ApiEnum;

@interface JSONHelper : NSObject

+(id)jsonToModel:(id)modelObj Api:(ApiEnum)apienum Idx:(NSInteger)idx ImageURL:(NSString *)url;

@end
