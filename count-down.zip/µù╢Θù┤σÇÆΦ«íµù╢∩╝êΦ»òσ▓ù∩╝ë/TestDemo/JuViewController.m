//
//  JuViewController.m
//  TestDemo
//
//  Created by zhuang on 16/11/21.
//  Copyright © 2016年 song. All rights reserved.
//

#import "JuViewController.h"
#import "AFAppDotNetAPIClient.h"
#import "CountDown.h"



#define screenWeith self.view.frame.size.width
#define screenHeight self.view.frame.size.height

@interface JuViewController ()
@property (nonatomic, strong)UIScrollView *backScrollView;
@property (nonatomic, strong)UIButton *leftButton;
@property (nonatomic, strong)UIButton *rightButton;
@property (nonatomic, strong)UIView *whiteView;
@property (nonatomic, strong)UIImageView *upImageView;
@property (nonatomic, strong)UIImageView *coinImage;
@property (nonatomic, strong)UILabel *overLabel;
@property (nonatomic, strong)UILabel *dayLabel;
@property (nonatomic, strong)UILabel *dayNumLabel;
@property (nonatomic, strong)UILabel *hourLabel;
@property (nonatomic, strong)UILabel *hourNumLabel;
@property (nonatomic, strong)UILabel *minLabel;
@property (nonatomic, strong)UILabel *minNumLabel;
@property (nonatomic, strong)UILabel *seconLabel;
@property (nonatomic, strong)UILabel *seconNumLabel;
@property (nonatomic, strong)UIImageView *downImageView;
@property (nonatomic, strong)UILabel *numLabel;
@property (nonatomic, strong)UIView *whiteSecondView;
@property (nonatomic, strong)UIButton *noticeButton;
@property (nonatomic, strong)UIButton *buyButton;
@property (nonatomic, strong)UIView *whiteMidView;
@property (nonatomic, strong)UIImageView *trendsImageView;
@property (nonatomic, strong)UILabel *peopleLabel;
@property (nonatomic, strong)UILabel *peopleNumLabel;
@property (nonatomic, strong)UIImageView *coinTwoImageView;
@property (nonatomic, strong)UIView *whiteThirdView;
@property (nonatomic, strong)UILabel *girlLabel;
@property (nonatomic, strong)UILabel *boyLabel;

@property (nonatomic, strong)UIImageView *firstImageView;
@property (nonatomic, strong)UIImageView *secondImageView;
@property (nonatomic, strong)UIImageView *thirdImageView;
@property (nonatomic, strong)UIImageView *forthImageView;
@property (nonatomic, strong)UIImageView *fifthImageView;
@property (nonatomic, strong)UIButton *fifthButton;
@property (nonatomic, strong)NSDictionary *dataDic;

@property (strong, nonatomic)  CountDown *countDownForLabel;

@end

@implementation JuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"活动介绍";
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationController.navigationBar.translucent = NO;
    
    [self creatView];
    
    [self loadData];
}

#pragma mark - UI:
- (void)creatView{
    //设置左按钮
    self.leftButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 27, 27)];
    [self.leftButton setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.leftButton];
    [self.leftButton addTarget:self action:@selector(LeftAction) forControlEvents:UIControlEventTouchUpInside];
    
    
    //设置右按钮
    self.rightButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 27, 27)];
    [self.rightButton setImage:[UIImage imageNamed:@"share"] forState:UIControlStateNormal];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.rightButton];
    [self.rightButton addTarget:self action:@selector(RightAction) forControlEvents:UIControlEventTouchUpInside];
    

    
    //整体背景ScrollView
    self.backScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, screenWeith, screenHeight)];
    self.backScrollView.showsVerticalScrollIndicator = NO;
    self.backScrollView.backgroundColor = [UIColor colorWithRed:0.93 green:0.93 blue:0.94 alpha:1.00];
    [self.view addSubview:self.backScrollView];
    

    //设置购买按钮
    self.buyButton = [[UIButton alloc] initWithFrame:CGRectMake(10, screenHeight - 55 - 64, screenWeith - 20, 45)];
    [self.buyButton setTitle:@"立即购买" forState:UIControlStateNormal];
    [self.buyButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.buyButton.backgroundColor = [UIColor colorWithRed:0.93 green:0.00 blue:0.28 alpha:1.00];
    [self.view addSubview:self.buyButton];
    [self.buyButton addTarget:self action:@selector(buyAction) forControlEvents:UIControlEventTouchUpInside];
    self.buyButton.layer.masksToBounds = YES;
    self.buyButton.layer.cornerRadius = 5;
    
    //设置须知按钮
    self.noticeButton = [[UIButton alloc] initWithFrame:CGRectMake(10, self.buyButton.frame.origin.y - 55, screenWeith - 20, 45)];
    [self.noticeButton setTitle:@"购票须知" forState:UIControlStateNormal];
    [self.noticeButton setTitleColor:[UIColor colorWithRed:0.52 green:0.52 blue:0.52 alpha:1.00] forState:UIControlStateNormal];
     self.noticeButton.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.noticeButton];
    [self.noticeButton addTarget:self action:@selector(noticeAction) forControlEvents:UIControlEventTouchUpInside];
    self.noticeButton.layer.masksToBounds = YES;
    self.noticeButton.layer.cornerRadius = 5;
    
    
    self.whiteView = [[UIView alloc] initWithFrame:CGRectMake(10, 10, screenWeith - 20, 145 + 45)];
    self.whiteView.backgroundColor = [UIColor whiteColor];
    self.whiteView.layer.masksToBounds = YES;
    self.whiteView.layer.cornerRadius = 5;
    [self.backScrollView addSubview:self.whiteView];
    
    self.upImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.whiteView.frame.size.width, 145)];
    self.upImageView.image = [UIImage imageNamed:@"demo"];
    [self.whiteView addSubview:self.upImageView];
    
    self.coinImage = [[UIImageView alloc] initWithFrame:CGRectMake(50, self.upImageView.frame.origin.y + self.upImageView.frame.size.height + 10, 25, 25)];
    self.coinImage.image = [UIImage imageNamed:@"detail"];
    [self.whiteView addSubview:self.coinImage];
    
    self.overLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.coinImage.frame.origin.x + self.coinImage.frame.size.width, self.coinImage.frame.origin.y - 2, 40, 30)];
    self.overLabel.text = @"剩余:";
    self.overLabel.font = [UIFont systemFontOfSize:16];
    self.overLabel.textColor = [UIColor colorWithRed:0.52 green:0.52 blue:0.52 alpha:1.00];
    [self.whiteView addSubview:self.overLabel];
    
    self.dayLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.overLabel.frame.origin.x + self.overLabel.frame.size.width + 5, self.overLabel.frame.origin.y, 20, 30)];
//    self.dayLabel.text = @"8";
    self.dayLabel.font = [UIFont systemFontOfSize:16];
    self.dayLabel.textColor = [UIColor redColor];
    self.dayLabel.textAlignment = NSTextAlignmentCenter;
    [self.whiteView addSubview:self.dayLabel];

    
    self.dayNumLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.dayLabel.frame.origin.x + self.dayLabel.frame.size.width, self.overLabel.frame.origin.y, 17, 30)];
    self.dayNumLabel.text = @"天";
    self.dayNumLabel.font = [UIFont systemFontOfSize:16];
    self.dayNumLabel.textColor = [UIColor colorWithRed:0.52 green:0.52 blue:0.52 alpha:1.00];
    [self.whiteView addSubview:self.dayNumLabel];
    
    self.hourLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.dayNumLabel.frame.origin.x + self.dayNumLabel.frame.size.width, self.overLabel.frame.origin.y, 20, 30)];
//    self.hourLabel.text = @"09";
    self.hourLabel.font = [UIFont systemFontOfSize:16];
    self.hourLabel.textColor = [UIColor redColor];
    self.hourLabel.textAlignment = NSTextAlignmentCenter;
    [self.whiteView addSubview:self.hourLabel];
    
    
    self.hourNumLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.hourLabel.frame.origin.x + self.hourLabel.frame.size.width, self.overLabel.frame.origin.y, 33, 30)];
    self.hourNumLabel.text = @"小时";
    self.hourNumLabel.font = [UIFont systemFontOfSize:16];
    self.hourNumLabel.textColor = [UIColor colorWithRed:0.52 green:0.52 blue:0.52 alpha:1.00];
    [self.whiteView addSubview:self.hourNumLabel];
    
    self.minLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.hourNumLabel.frame.origin.x + self.hourNumLabel.frame.size.width, self.overLabel.frame.origin.y, 20, 30)];
    self.minLabel.text = @"35";
    self.minLabel.font = [UIFont systemFontOfSize:16];
    self.minLabel.textAlignment = NSTextAlignmentCenter;
    self.minLabel.textColor = [UIColor redColor];
    
    [self.whiteView addSubview:self.minLabel];
    
    
    self.minNumLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.minLabel.frame.origin.x + self.minLabel.frame.size.width, self.overLabel.frame.origin.y, 15, 30)];
    self.minNumLabel.text = @"分";
    self.minNumLabel.font = [UIFont systemFontOfSize:16];
    self.minNumLabel.textColor = [UIColor colorWithRed:0.52 green:0.52 blue:0.52 alpha:1.00];
    [self.whiteView addSubview:self.minNumLabel];
    
    self.seconLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.minNumLabel.frame.origin.x + self.minNumLabel.frame.size.width, self.overLabel.frame.origin.y, 20, 30)];
    self.seconLabel.text = @"23";
    self.seconLabel.font = [UIFont systemFontOfSize:16];
    self.seconLabel.textColor = [UIColor redColor];
    self.seconLabel.textAlignment = NSTextAlignmentCenter;
    [self.whiteView addSubview:self.seconLabel];
    
    
    self.seconNumLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.seconLabel.frame.origin.x + self.seconLabel.frame.size.width, self.overLabel.frame.origin.y, 15, 30)];
    self.seconNumLabel.text = @"秒";
    self.seconNumLabel.font = [UIFont systemFontOfSize:16];
    self.seconNumLabel.textColor = [UIColor colorWithRed:0.52 green:0.52 blue:0.52 alpha:1.00];
    [self.whiteView addSubview:self.seconNumLabel];

    
    self.downImageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, self.whiteView.frame.origin.y + self.whiteView.frame.size.height + 10, screenWeith - 20, 100)];
    self.downImageView.image = [UIImage imageNamed:@"demo"];
    self.downImageView.layer.masksToBounds = YES;
    self.downImageView.layer.cornerRadius = 5;
    [self.backScrollView addSubview:self.downImageView];
    
    self.numLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, self.downImageView.frame.origin.y + self.downImageView.frame.size.height + 15, screenWeith - 20, 30)];
    self.numLabel.font = [UIFont systemFontOfSize:15];
    self.numLabel.textColor = [UIColor colorWithRed:0.52 green:0.52 blue:0.52 alpha:1.00];
    self.numLabel.numberOfLines = 0;
    [self.numLabel sizeToFit];
    [self.backScrollView addSubview:self.numLabel];

    
    self.whiteSecondView = [[UIView alloc] initWithFrame:CGRectMake(10, self.numLabel.frame.origin.y + self.numLabel.frame.size.height + 10, screenWeith - 20, 100)];
    self.whiteSecondView.backgroundColor = [UIColor whiteColor];
    self.whiteSecondView.layer.masksToBounds = YES;
    self.whiteSecondView.layer.cornerRadius = 5;
    [self.backScrollView addSubview:self.whiteSecondView];
    
    //550/118
    self.trendsImageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 270, 270 * 118 / 550)];
//    self.trendsImageView.image = [UIImage imageNamed:@"demo"];
    [self.whiteSecondView addSubview:self.trendsImageView];
    
    
    self.peopleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, self.trendsImageView.frame.origin.y + self.trendsImageView.frame.size.height, self.whiteSecondView.frame.size.width, 30)];
//    self.peopleLabel.text = @"ajslfjalsdfkjalsdkfjasldkfj";
    self.peopleLabel.font = [UIFont systemFontOfSize:12];
    self.peopleLabel.textColor = [UIColor colorWithRed:0.52 green:0.52 blue:0.52 alpha:1.00];
    self.peopleLabel.textAlignment = NSTextAlignmentCenter;
    [self.whiteSecondView addSubview:self.peopleLabel];

    self.coinTwoImageView = [[UIImageView alloc] initWithFrame:CGRectMake(self.trendsImageView.frame.origin.x + self.trendsImageView.frame.size.width + 10, self.trendsImageView.frame.origin.y + self.trendsImageView.frame.size.height - 20, 25, 25)];
    self.coinTwoImageView.image = [UIImage imageNamed:@"down"];
    [self.whiteSecondView addSubview:self.coinTwoImageView];

    self.peopleNumLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.coinTwoImageView.frame.origin.x + self.coinTwoImageView.frame.size.width, self.coinTwoImageView.frame.origin.y - 2, 50, 30)];
    self.peopleNumLabel.text = @"6/24";
    self.peopleNumLabel.font = [UIFont systemFontOfSize:15];
    self.peopleNumLabel.textColor = [UIColor colorWithRed:0.38 green:0.85 blue:0.91 alpha:1.00];
    [self.whiteSecondView addSubview:self.peopleNumLabel];

    
    
    
    
    
    
    self.firstImageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, self.whiteSecondView.frame.origin.y + self.whiteSecondView.frame.size.height + 10, (screenWeith - 60) / 5, (screenWeith - 60) / 5)];
    self.firstImageView.backgroundColor = [UIColor yellowColor];
    self.firstImageView.image = [UIImage imageNamed:@"people"];
    self.firstImageView.layer.masksToBounds = YES;
    self.firstImageView.layer.cornerRadius = 5;
    [self.backScrollView addSubview:self.firstImageView];
    
    self.secondImageView = [[UIImageView alloc] initWithFrame:CGRectMake(self.firstImageView.frame.origin.x + self.firstImageView.frame.size.width + 10, self.firstImageView.frame.origin.y, (screenWeith - 60) / 5, (screenWeith - 60) / 5)];
    self.secondImageView.backgroundColor = [UIColor yellowColor];
    self.secondImageView.image = [UIImage imageNamed:@"people"];
    self.secondImageView.layer.masksToBounds = YES;
    self.secondImageView.layer.cornerRadius = 5;
    [self.backScrollView addSubview:self.secondImageView];
    
    self.thirdImageView = [[UIImageView alloc] initWithFrame:CGRectMake(self.secondImageView.frame.origin.x + self.secondImageView.frame.size.width + 10, self.firstImageView.frame.origin.y, (screenWeith - 60) / 5, (screenWeith - 60) / 5)];
    self.thirdImageView.backgroundColor = [UIColor yellowColor];
    self.thirdImageView.image = [UIImage imageNamed:@"people"];
    self.thirdImageView.layer.masksToBounds = YES;
    self.thirdImageView.layer.cornerRadius = 5;
    [self.backScrollView addSubview:self.thirdImageView];
    
    self.forthImageView = [[UIImageView alloc] initWithFrame:CGRectMake(self.thirdImageView.frame.origin.x + self.thirdImageView.frame.size.width + 10, self.firstImageView.frame.origin.y, (screenWeith - 60) / 5, (screenWeith - 60) / 5)];
    self.forthImageView.backgroundColor = [UIColor yellowColor];
    self.forthImageView.image = [UIImage imageNamed:@"people"];
    self.forthImageView.layer.masksToBounds = YES;
    self.forthImageView.layer.cornerRadius = 5;
    [self.backScrollView addSubview:self.forthImageView];
    
    self.fifthImageView = [[UIImageView alloc] initWithFrame:CGRectMake(self.forthImageView.frame.origin.x + self.forthImageView.frame.size.width + 10, self.firstImageView.frame.origin.y, (screenWeith - 60) / 5, (screenWeith - 60) / 5)];
    self.fifthImageView.backgroundColor = [UIColor yellowColor];
    self.fifthImageView.image = [UIImage imageNamed:@"people"];
    self.fifthImageView.layer.masksToBounds = YES;
    self.fifthImageView.layer.cornerRadius = 5;
//    [self.backScrollView addSubview:self.fifthImageView];
    
    
    
    
    
    self.fifthButton = [[UIButton alloc] initWithFrame:CGRectMake(self.forthImageView.frame.origin.x + self.forthImageView.frame.size.width + 10, self.firstImageView.frame.origin.y, (screenWeith - 60) / 5, (screenWeith - 60) / 5)];
    [self.fifthButton setTitle:@"更多" forState:UIControlStateNormal];
    [self.fifthButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.fifthButton.backgroundColor = [UIColor colorWithRed:0.20 green:0.69 blue:0.88 alpha:1.00];
    [self.backScrollView addSubview:self.fifthButton];
//    [self.fifthButton addTarget:self action:@selector(noticeAction) forControlEvents:UIControlEventTouchUpInside];
    self.fifthButton.layer.masksToBounds = YES;
    self.fifthButton.layer.cornerRadius = 5;

    
    
    self.whiteThirdView = [[UIView alloc] initWithFrame:CGRectMake(10, self.firstImageView.frame.origin.y + self.firstImageView.frame.size.height + 10, screenWeith - 20, 49)];
    self.whiteThirdView.backgroundColor = [UIColor whiteColor];
    self.whiteThirdView.layer.masksToBounds = YES;
    self.whiteThirdView.layer.cornerRadius = 5;
    [self.backScrollView addSubview:self.whiteThirdView];
    
    
    self.girlLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 9.5, self.whiteSecondView.frame.size.width / 2, 30)];
    self.girlLabel.font = [UIFont systemFontOfSize:17];
    self.girlLabel.textColor = [UIColor colorWithRed:0.94 green:0.17 blue:0.45 alpha:1.00];
    self.girlLabel.textAlignment = NSTextAlignmentCenter;
    [self.whiteThirdView addSubview:self.girlLabel];
    
    
    self.boyLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.whiteSecondView.frame.size.width / 2, self.girlLabel.frame.origin.y, self.whiteSecondView.frame.size.width / 2, 30)];
    self.boyLabel.font = [UIFont systemFontOfSize:17];
    self.boyLabel.textColor = [UIColor colorWithRed:0.94 green:0.17 blue:0.45 alpha:1.00];
    self.boyLabel.textAlignment = NSTextAlignmentCenter;
    [self.whiteThirdView addSubview:self.boyLabel];

    
     [self.backScrollView setContentSize:CGSizeMake(0, self.whiteThirdView.frame.origin.y + self.whiteThirdView.frame.size.height + 300)];

}

#pragma mark - AF:

- (void)loadData{
    
    NSString *URLString = @"http://liying02.dlcs.lcweb01.cn/Ajax/CJ_Main_Page.ashx";
    NSDictionary *parameters = @{@"t" : @"get_party_list", @"pageindex": @"0", @"pagesize" : @"0", @"type" : @"0", @"cid" : @"0"};
    

    [[AFAppDotNetAPIClient sharedClient] POST:URLString parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"成功");
        
        
        NSLog(@"Data = %@", responseObject);
        
       NSArray *dataArray = [responseObject objectForKey:@"list"];
       self.dataDic = [dataArray lastObject];
        
       [self zhi];
        
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"失败");

    }];
    
    

    
    
    
    
}


- (void)zhi{
    
    //倒计时
    
    //获取当前时间，日期
    NSDate *currentDate = [NSDate date];

    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"YYYY/MM/dd hh:mm:ss"];
    NSString *dateString = [dateFormatter stringFromDate:currentDate];
    NSLog(@"dateString:%@",dateString);
    //当前时间
    NSDate *date1 = [dateFormatter dateFromString:dateString];
    NSLog(@"date1 ====== %@", date1);
    


    //接口数据
    NSString *dateString2 = [self.dataDic objectForKey:@"start_date"];
    NSString *dateString22 = [self.dataDic objectForKey:@"start_time"];
    
    NSString *dateString222 = [NSString stringWithFormat:@"%@ %@", dateString2, dateString22];
    NSLog(@"dateString222 ====== %@", dateString222);

    //设置转换格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-ddHH:mm"];
    //NSString转NSDate
    NSDate*date2 = [formatter dateFromString:dateString222];
    NSLog(@"date2 ====== %@", date2);

    
    NSTimeInterval time = [date2 timeIntervalSinceDate:date1];
    NSLog(@"减后时间 ====== %f", time);
    
    int days= ((int)time)/(3600*24);
    int hours= ((int)time)%(3600*24)/3600;
    int minute = (int)(time - hours*3600 - days * (3600*24))/60;
    int second = time - hours*3600 - minute*60 - days * (3600*24);

    
    
    NSString *dateContent = [[NSString alloc] initWithFormat:@"%i天%i小时%i分%d秒", days,hours,minute,second];
    NSLog(@"减后........时间 ====== %@", dateContent);
    
    self.dayLabel.text = [NSString stringWithFormat:@"%d", days];
    self.hourLabel.text = [NSString stringWithFormat:@"%d", hours];
    self.minLabel.text = [NSString stringWithFormat:@"%d", minute];
    self.seconLabel.text = [NSString stringWithFormat:@"%d", second];

    
    
    _countDownForLabel = [[CountDown alloc] init];
    
    
    
    [self startWithStartDate:date1 finishDate:date2];

    
    
    //多行文字
    [self.numLabel setFrame:CGRectMake(10, self.downImageView.frame.origin.y + self.downImageView.frame.size.height + 15, screenWeith - 20, 30)];
    self.numLabel.text = [self.dataDic objectForKey:@"description"];
    
    self.numLabel.numberOfLines = 0;
    [self.numLabel sizeToFit];
    
    [self.whiteSecondView setFrame:CGRectMake(10, self.numLabel.frame.origin.y + self.numLabel.frame.size.height + 10, screenWeith - 20, 100)];
    [self.firstImageView setFrame:CGRectMake(10, self.whiteSecondView.frame.origin.y + self.whiteSecondView.frame.size.height + 10, (screenWeith - 60) / 5, (screenWeith - 60) / 5)];
    [self.secondImageView setFrame:CGRectMake(self.firstImageView.frame.origin.x + self.firstImageView.frame.size.width + 10, self.firstImageView.frame.origin.y, (screenWeith - 60) / 5, (screenWeith - 60) / 5)];
    
    [self.thirdImageView setFrame:CGRectMake(self.secondImageView.frame.origin.x + self.secondImageView.frame.size.width + 10, self.firstImageView.frame.origin.y, (screenWeith - 60) / 5, (screenWeith - 60) / 5)];
    [self.forthImageView setFrame:CGRectMake(self.thirdImageView.frame.origin.x + self.thirdImageView.frame.size.width + 10, self.firstImageView.frame.origin.y, (screenWeith - 60) / 5, (screenWeith - 60) / 5)];
    [self.fifthImageView setFrame:CGRectMake(self.forthImageView.frame.origin.x + self.forthImageView.frame.size.width + 10, self.firstImageView.frame.origin.y, (screenWeith - 60) / 5, (screenWeith - 60) / 5)];
    [self.fifthButton setFrame:CGRectMake(self.forthImageView.frame.origin.x + self.forthImageView.frame.size.width + 10, self.firstImageView.frame.origin.y, (screenWeith - 60) / 5, (screenWeith - 60) / 5)];
    [self.whiteThirdView setFrame:CGRectMake(10, self.firstImageView.frame.origin.y + self.firstImageView.frame.size.height + 10, screenWeith - 20, 49)];
    [self.backScrollView setContentSize:CGSizeMake(0, self.whiteThirdView.frame.origin.y + self.whiteThirdView.frame.size.height + 300)];

    //比例图
    NSString *string = [self.dataDic objectForKey:@"in_woman_num"];
    NSString *string2 = [self.dataDic objectForKey:@"in_man_num"];
    NSString *string3 = [self.dataDic objectForKey:@"max_num"];

    self.peopleLabel.text = [NSString stringWithFormat:@"已购票女生%@人男生%@人, 活动总人数%@人", string, string2, string3];
    
    NSInteger maler = [string integerValue];
    NSInteger femaler = [string2 integerValue];

    NSString *string4 = [NSString stringWithFormat:@"%ld", maler + femaler];
    self.peopleNumLabel.text = [NSString stringWithFormat:@"%@/%@", string4, string3];
    
    float male = [string floatValue];
    float female = [string2 floatValue];
    
    float total2 = male + female;
    float total1 = [string3 floatValue];
    float total = total2 / total1;

    if (total == 0.0) {
        self.trendsImageView.image = [UIImage imageNamed:@"tiao0"];
        
    } else if (0.0 < total <= 0.1) {
        self.trendsImageView.image = [UIImage imageNamed:@"tiao1"];
        
    } else if (0.1 < total <= 0.2) {
        self.trendsImageView.image = [UIImage imageNamed:@"tiao2"];

    } else if (0.2 < total <= 0.3) {
        self.trendsImageView.image = [UIImage imageNamed:@"tiao3"];
        
    } else if (0.3 < total <= 0.4) {
        self.trendsImageView.image = [UIImage imageNamed:@"tiao4"];
        
    } else if (0.4 < total <= 0.5) {
        self.trendsImageView.image = [UIImage imageNamed:@"tiao5"];
        
    } else if (0.5 < total <= 0.6) {
        self.trendsImageView.image = [UIImage imageNamed:@"tiao6"];
        
    } else if (0.6 < total <= 0.7) {
        self.trendsImageView.image = [UIImage imageNamed:@"tiao7"];
        
    } else if (0.7 < total <= 0.8) {
        self.trendsImageView.image = [UIImage imageNamed:@"tiao8"];
        
    } else if (0.8 < total <= 0.9) {
        self.trendsImageView.image = [UIImage imageNamed:@"tiao9"];
        
    } else if (0.9 < total <= 1.0) {
        self.trendsImageView.image = [UIImage imageNamed:@"tiao10"];
        
    } else {
        
    }
    
    
    //男女生票价
    NSString *boyString = [self.dataDic objectForKey:@"man_price"];
    NSString *girlString = [self.dataDic objectForKey:@"woman_price"];
    
    int boy = [boyString intValue];
    int girl = [girlString intValue];

    self.boyLabel.text = [NSString stringWithFormat:@"女男生票 ¥%d", boy];
    self.girlLabel.text = [NSString stringWithFormat:@"女生票 ¥%d", girl];
    
    
//    [self.whiteThirdView setFrame:CGRectMake(10, self.firstImageView.frame.origin.y + self.firstImageView.frame.size.height + 10, screenWeith - 20, 49)];
//    
//    [self.backScrollView setFrame:CGRectMake(0, 0, screenWeith, self.whiteThirdView.frame.origin.y + self.whiteThirdView.frame.size.height)];


}


#pragma mark - Action:
- (void)LeftAction{
    
}

- (void)RightAction{
    
}

- (void)buyAction{
    
}

- (void)noticeAction{
    
}


///此方法用两个时间戳做参数进行倒计时
-(void)startLongLongStartStamp:(long long)strtLL longlongFinishStamp:(long long)finishLL{
    __weak __typeof(self) weakSelf= self;
    
    [_countDownForLabel countDownWithStratTimeStamp:strtLL finishTimeStamp:finishLL completeBlock:^(NSInteger day, NSInteger hour, NSInteger minute, NSInteger second) {
        NSLog(@"666");
        [weakSelf refreshUIDay:day hour:hour minute:minute second:second];
    }];
}


//此方法用两个NSDate对象做参数进行倒计时
-(void)startWithStartDate:(NSDate *)strtDate finishDate:(NSDate *)finishDate{
    __weak __typeof(self) weakSelf= self;
    
    [_countDownForLabel countDownWithStratDate:strtDate finishDate:finishDate completeBlock:^(NSInteger day, NSInteger hour, NSInteger minute, NSInteger second) {
        [weakSelf refreshUIDay:day hour:hour minute:minute second:second];
        
    }];
}


- (void)refreshUIDay:(NSInteger)day hour:(NSInteger)hour minute:(NSInteger)minute second:(NSInteger)second{
    if (day==0) {
        self.dayLabel.text = @"0";
    }else{
        self.dayLabel.text = [NSString stringWithFormat:@"%ld",(long)day];
    }
    if (hour<10&&hour) {
        self.hourLabel.text = [NSString stringWithFormat:@"0%ld",(long)hour];
    }else{
        self.hourLabel.text = [NSString stringWithFormat:@"%ld",(long)hour];
    }
    if (minute<10) {
        self.minLabel.text = [NSString stringWithFormat:@"0%ld",(long)minute];
    }else{
        self.minLabel.text = [NSString stringWithFormat:@"%ld",(long)minute];
    }
    if (second<10) {
        self.seconLabel.text = [NSString stringWithFormat:@"0%ld",(long)second];
    }else{
        self.seconLabel.text = [NSString stringWithFormat:@"%ld",(long)second];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
