////
////  JSONHelper.m
////  Houses
////
////  Created by Liang Zhang on 14/12/15.
////  Copyright (c) 2014年 bangbangtianxia. All rights reserved.
////
//
#import "JSONHelper.h"
#import "NetworkHelper.h"

@implementation JSONHelper
//
//+(id)jsonToModel:(id)modelObj Api:(ApiEnum)apienum Idx:(NSInteger)idx ImageURL:(NSString *)url {
//    
//    switch (apienum) {
//            
//        case ApiEnumSaveChannelId://保存推送号
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//        }
//            break;
//            
//        case ApiEnumSMSCode://验证码
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//        }
//            break;
//        case ApiEnumGetBackPwd://找回密码
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            RegistUserModel *model = [[RegistUserModel alloc] init];
//            model.mpasswd = [NetworkHelper makeModelValueWithKey:@"mpasswd" Model:dic Null:@""];
//            model.user_id = [NetworkHelper makeModelValueWithKey:@"user_id" Model:dic Null:@""];
//            
//            return model;
//        }
//            break;
//            
//        case ApiEnumRegistUser://用户注册
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            RegistUserModel *model = [[RegistUserModel alloc] init];
//            model.mpasswd = [NetworkHelper makeModelValueWithKey:@"mpasswd" Model:dic Null:@""];
//            model.user_id = [NetworkHelper makeModelValueWithKey:@"user_id" Model:dic Null:@""];
//            
//            return model;
//        }
//            break;
//            
//        case ApiEnumLogin://用户登录
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            LoginModel *model = [[LoginModel alloc] init];
//            model.company_id = [NetworkHelper makeModelValueWithKey:@"company_id" Model:dic Null:@""];
//            model.u_status = [NetworkHelper makeModelValueWithKey:@"u_status" Model:dic Null:@""];
//            model.user_id = [NetworkHelper makeModelValueWithKey:@"user_id" Model:dic Null:@""];
//            model.user_type = [NetworkHelper makeModelValueWithKey:@"user_type" Model:dic Null:@""];
//            model.msg_status = [NetworkHelper makeModelValueWithKey:@"msg_status" Model:dic Null:@""];
//            
//            return model;
//            
//        }
//            break;
//            
//        case ApiEnumGetInfoList://资讯列表
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            NewsListModel *model = [[NewsListModel alloc] init];
//            model.news_id = [NetworkHelper makeModelValueWithKey:@"news_id" Model:dic Null:@""];
//            model.news_title = [NetworkHelper makeModelValueWithKey:@"news_title" Model:dic Null:@""];
//            model.newsDescription = [NetworkHelper makeModelValueWithKey:@"description" Model:dic Null:@""];
//            model.dateline = [NetworkHelper makeModelValueWithKey:@"dateline" Model:dic Null:@""];
//            model.news_pic = [NetworkHelper makeModelValueWithKey:@"news_pic" Model:dic Null:@""];
//            model.news_author = [NetworkHelper makeModelValueWithKey:@"news_author" Model:dic Null:@""];
//            model.news_url = [NetworkHelper makeModelValueWithKey:@"news_url" Model:dic Null:@""];
//            return model;
//            
//        }
//            break;
//            
//        case ApiEnumGetFreightShow://今日运费
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            TodayShowModel *model = [[TodayShowModel alloc] init];
//            model.url = [NetworkHelper makeModelValueWithKey:@"url" Model:dic Null:@""];
//            model.title = [NetworkHelper makeModelValueWithKey:@"title" Model:dic Null:@""];
//            model.descriptionString = [NetworkHelper makeModelValueWithKey:@"description" Model:dic Null:@""];
//            model.img = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"img" Model:dic Null:@""]];
//            return model;
//        }
//            break;
//        case ApiEnumGetProductShow://今日煤价
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            TodayShowModel *model = [[TodayShowModel alloc] init];
//            model.url = [NetworkHelper makeModelValueWithKey:@"url" Model:dic Null:@""];
//            model.title = [NetworkHelper makeModelValueWithKey:@"title" Model:dic Null:@""];
//            model.descriptionString = [NetworkHelper makeModelValueWithKey:@"description" Model:dic Null:@""];
//            model.img = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"img" Model:dic Null:@""]];
//            
//            return model;
//        }
//            break;
//            
//        case ApiEnumGetBroadcastTraffic://路况
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            TodayShowModel *model = [[TodayShowModel alloc] init];
//            model.url = [NetworkHelper makeModelValueWithKey:@"url" Model:dic Null:@""];
//            model.title = [NetworkHelper makeModelValueWithKey:@"title" Model:dic Null:@""];
//            model.descriptionString = [NetworkHelper makeModelValueWithKey:@"description" Model:dic Null:@""];
//            model.img = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"img" Model:dic Null:@""]];
//            
//            return model;
//        }
//            break;
//            
//        case ApiEnumGetBroadcastWeather ://天气播报
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            TodayShowModel *model = [[TodayShowModel alloc] init];
//            model.url = [NetworkHelper makeModelValueWithKey:@"url" Model:dic Null:@""];
//            model.title = [NetworkHelper makeModelValueWithKey:@"title" Model:dic Null:@""];
//            model.descriptionString = [NetworkHelper makeModelValueWithKey:@"description" Model:dic Null:@""];
//            model.img = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"img" Model:dic Null:@""]];
//            
//            return model;
//        }
//            break;
//            
//        case ApiEnumTransportsGetOrdersList://司机端货源列表
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            TransportsGetOrderListModel *model = [[TransportsGetOrderListModel alloc] init];
//            model.tso_id = [NetworkHelper makeModelValueWithKey:@"tso_id" Model:dic Null:@""];
//            model.from = [NetworkHelper makeModelValueWithKey:@"from" Model:dic Null:@""];
//            model.to = [NetworkHelper makeModelValueWithKey:@"to" Model:dic Null:@""];
//            model.contact = [NetworkHelper makeModelValueWithKey:@"contact" Model:dic Null:@""];
//            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            model.load_cost = [NetworkHelper makeModelValueWithKey:@"load_cost" Model:dic Null:@""];
//            model.unload_cost = [NetworkHelper makeModelValueWithKey:@"unload_cost" Model:dic Null:@""];
//            model.avatar = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"avatar" Model:dic Null:@""]];;
//            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            model. trans_num = [NetworkHelper makeModelValueWithKey:@"trans_num" Model:dic Null:@""];
//            
//            return model;
//        }
//            break;
//            
//            //        case ApiEnumAutoLogin://自动登录
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            LoginModel *model = [[LoginModel alloc] init];
//            //            model.address = [NetworkHelper makeModelValueWithKey:@"address" Model:dic Null:@""];
//            //            model.area = [NetworkHelper makeModelValueWithKey:@"area" Model:dic Null:@""];
//            //            model.avatar = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"avatar" Model:dic Null:@""]];
//            //            model.ceil_phone = [NetworkHelper makeModelValueWithKey:@"ceil_phone" Model:dic Null:@""];
//            //            model.city = [NetworkHelper makeModelValueWithKey:@"city" Model:dic Null:@""];
//            //            model.company_id = [NetworkHelper makeModelValueWithKey:@"company_id" Model:dic Null:@""];
//            //            model.company_name = [NetworkHelper makeModelValueWithKey:@"company_name" Model:dic Null:@""];
//            //            model.county = [NetworkHelper makeModelValueWithKey:@"county" Model:dic Null:@""];
//            //            model.is_busy = [NetworkHelper makeModelValueWithKey:@"is_busy" Model:dic Null:@""];
//            //            model.manage_owner = [NetworkHelper makeModelValueWithKey:@"manage_owner" Model:dic Null:@""];
//            //            model.paper_no = [NetworkHelper makeModelValueWithKey:@"paper_no" Model:dic Null:@""];
//            //            model.passwd = [NetworkHelper makeModelValueWithKey:@"passwd" Model:dic Null:@""];
//            //            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            //            model.position = [NetworkHelper makeModelValueWithKey:@"position" Model:dic Null:@""];
//            //            model.province = [NetworkHelper makeModelValueWithKey:@"province" Model:dic Null:@""];
//            //            model.realname = [NetworkHelper makeModelValueWithKey:@"realname" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.unread_res = [NetworkHelper makeModelValueWithKey:@"unread_res" Model:dic Null:@""];
//            //            model.user_id = [NetworkHelper makeModelValueWithKey:@"user_id" Model:dic Null:@""];
//            //            model.utype_id = [NetworkHelper makeModelValueWithKey:@"utype_id" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //        case ApiEnumAudiInfo://返回审核信息
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            AudiInfoModel *model = [[AudiInfoModel alloc] init];
//            //            model.user_id = [NetworkHelper makeModelValueWithKey:@"user_id" Model:dic Null:@""];
//            //            model.realname = [NetworkHelper makeModelValueWithKey:@"realname" Model:dic Null:@""];
//            //            model.utype_id = [NetworkHelper makeModelValueWithKey:@"utype_id" Model:dic Null:@""];
//            //            model.company_name = [NetworkHelper makeModelValueWithKey:@"company_name" Model:dic Null:@""];
//            //            model.paper_no = [NetworkHelper makeModelValueWithKey:@"paper_no" Model:dic Null:@""];
//            //            model.identity = [NetworkHelper makeModelValueWithKey:@"identity" Model:dic Null:@""];
//            //            model.business = [NetworkHelper makeModelValueWithKey:@"business" Model:dic Null:@""];
//            //            model.driving = [NetworkHelper makeModelValueWithKey:@"driving" Model:dic Null:@""];
//            //            model.vehicle = [NetworkHelper makeModelValueWithKey:@"vehicle" Model:dic Null:@""];
//            //            model.operate = [NetworkHelper makeModelValueWithKey:@"operate" Model:dic Null:@""];
//            //            model.address = [NetworkHelper makeModelValueWithKey:@"address" Model:dic Null:@""];
//            //            model.position = [NetworkHelper makeModelValueWithKey:@"position" Model:dic Null:@""];
//            //            model.city = [NetworkHelper makeModelValueWithKey:@"city" Model:dic Null:@""];
//            //            model.province = [NetworkHelper makeModelValueWithKey:@"province" Model:dic Null:@""];
//            //            model.county = [NetworkHelper makeModelValueWithKey:@"county" Model:dic Null:@""];
//            //            model.manage_phone = [NetworkHelper makeModelValueWithKey:@"manage_phone" Model:dic Null:@""];
//            //            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            //
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.notes = [NetworkHelper makeModelValueWithKey:@"notes" Model:dic Null:@""];
//            //
//            //            model.province_name = [NetworkHelper makeModelValueWithKey:@"province_name" Model:dic Null:@""];
//            //            model.city_name = [NetworkHelper makeModelValueWithKey:@"city_name" Model:dic Null:@""];
//            //            model.county_name = [NetworkHelper makeModelValueWithKey:@"county_name" Model:dic Null:@""];
//            //            model.province_id = [NetworkHelper makeModelValueWithKey:@"province_id" Model:dic Null:@""];
//            //            model.city_id = [NetworkHelper makeModelValueWithKey:@"city_id" Model:dic Null:@""];
//            //            model.county_id = [NetworkHelper makeModelValueWithKey:@"county_id" Model:dic Null:@""];
//            //
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumCheckAuditImg://返回审核图片信息
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            CheckAuditImgModel *model = [[CheckAuditImgModel alloc] init];
//            //            model.identity = [NetworkHelper makeModelValueWithKey:@"identity" Model:dic Null:@""];
//            //            model.business = [NetworkHelper makeModelValueWithKey:@"business" Model:dic Null:@""];
//            //            model.driving = [NetworkHelper makeModelValueWithKey:@"driving" Model:dic Null:@""];
//            //            model.vehicle = [NetworkHelper makeModelValueWithKey:@"vehicle" Model:dic Null:@""];
//            //            model.operate = [NetworkHelper makeModelValueWithKey:@"operate" Model:dic Null:@""];
//            //
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //
//            //        case ApiEnumAudi://提交审核
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //        case ApiENumUploadPhoto://上传图片
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            uploadPhotoModel *model = [[uploadPhotoModel alloc] init];
//            //
//            //
//            //            model.paper_path = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"paper_path" Model:dic Null:@""]];
//            //
//            //            model.paper_id = [NetworkHelper makeModelValueWithKey:@"paper_id" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//        case ApiEnumGetCarouselPic://轮播图
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            getCarouselPicModel *model = [[getCarouselPicModel alloc] init];
//            model.types = [NetworkHelper makeModelValueWithKey:@"types" Model:dic Null:@""];
//            model.page_url = [NetworkHelper makeModelValueWithKey:@"page_url" Model:dic Null:@""];
//            model.CarouselPicDescription = [NetworkHelper makeModelValueWithKey:@"description" Model:dic Null:@""];
//            model.picture = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"picture" Model:dic Null:@""]];
//            model.content = [NetworkHelper makeModelValueWithKey:@"content" Model:dic Null:@""];
//            model.CarouselPicId = [NetworkHelper makeModelValueWithKey:@"id" Model:dic Null:@""];
//            
//            return model;
//            
//        }
//            break;
//            //        case ApiEnumCurrentStocks://获取当前库存
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            CurrentStocksModel *model = [[CurrentStocksModel alloc] init];
//            //            model.stock_id = [NetworkHelper makeModelValueWithKey:@"stock_id" Model:dic Null:@""];
//            //            model.current = [NetworkHelper makeModelValueWithKey:@"current" Model:dic Null:@""];
//            //            model.daily_fc = [NetworkHelper makeModelValueWithKey:@"daily_fc" Model:dic Null:@""];
//            //            model.alarm_ton = [NetworkHelper makeModelValueWithKey:@"alarm_ton" Model:dic Null:@""];
//            //            model.total = [NetworkHelper makeModelValueWithKey:@"total" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumSysmsgList://消息列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            SysmsgListModel *model = [[SysmsgListModel alloc] init];
//            //            model.msg_id = [NetworkHelper makeModelValueWithKey:@"msg_id" Model:dic Null:@""];
//            //            model.msg_title = [NetworkHelper makeModelValueWithKey:@"msg_title" Model:dic Null:@""];
//            //            model.msg_content = [NetworkHelper makeModelValueWithKey:@"msg_content" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.msg_type = [NetworkHelper makeModelValueWithKey:@"msg_type" Model:dic Null:@""];
//            //            model.msg_status = [NetworkHelper makeModelValueWithKey:@"msg_status" Model:dic Null:@""];
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumDelMsg://删除消息
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumSysmsgInfo://消息详情
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            SysmsgInfoModel *model = [[SysmsgInfoModel alloc] init];
//            //            model.msg_id = [NetworkHelper makeModelValueWithKey:@"msg_id" Model:dic Null:@""];
//            //            model.msg_title = [NetworkHelper makeModelValueWithKey:@"msg_title" Model:dic Null:@""];
//            //            model.msg_content = [NetworkHelper makeModelValueWithKey:@"msg_content" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumProductList://煤炭交易
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            ProductListModel *model = [[ProductListModel alloc] init];
//            //            model.product_id = [NetworkHelper makeModelValueWithKey:@"product_id" Model:dic Null:@""];
//            //            model.product_name = [NetworkHelper makeModelValueWithKey:@"product_name" Model:dic Null:@""];
//            //            model.cate_id = [NetworkHelper makeModelValueWithKey:@"cate_id" Model:dic Null:@""];
//            //            model.price = [NetworkHelper makeModelValueWithKey:@"price" Model:dic Null:@""];
//            //
//            //            model.calorific_value = [NetworkHelper makeModelValueWithKey:@"calorific_value" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.rate = [NetworkHelper makeModelValueWithKey:@"rate" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.process = [NetworkHelper makeModelValueWithKey:@"process" Model:dic Null:@""];
//            //            model.activities = [NetworkHelper makeModelValueWithKey:@"activities" Model:dic Null:@""];
//            //            return model;
//            //        }
//            //            break;
//            //
//            //
//            //        case ApiEnumShippingAddressDefault://默认收货
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            ShippingAddressDefaultModel *model = [[ShippingAddressDefaultModel alloc] init];
//            //            model.ra_id = [NetworkHelper makeModelValueWithKey:@"ra_id" Model:dic Null:@""];
//            //            model.contact = [NetworkHelper makeModelValueWithKey:@"contact" Model:dic Null:@""];
//            //            model.phone = [NetworkHelper makeModelValueWithKey:@"phone" Model:dic Null:@""];
//            //            model.address = [NetworkHelper makeModelValueWithKey:@"address" Model:dic Null:@""];
//            //            return model;
//            //        }
//            //            break;
//            //
//        case ApiEnumTransportsGetOrderInfo://货源详情
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            TransportsGetOrderInfoModel *model = [[TransportsGetOrderInfoModel alloc] init];
//            model.tso_id = [NetworkHelper makeModelValueWithKey:@"tso_id" Model:dic Null:@""];
//            model.contact = [NetworkHelper makeModelValueWithKey:@"contact" Model:dic Null:@""];
//            model.left_trans = [NetworkHelper makeModelValueWithKey:@"left_trans" Model:dic Null:@""];
//            model.from = [NetworkHelper makeModelValueWithKey:@"from" Model:dic Null:@""];
//            model.to = [NetworkHelper makeModelValueWithKey:@"to" Model:dic Null:@""];
//            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            model.load_cost = [NetworkHelper makeModelValueWithKey:@"load_cost" Model:dic Null:@""];
//            model.unload_cost = [NetworkHelper makeModelValueWithKey:@"unload_cost" Model:dic Null:@""];
//            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            model.freight_paytype = [NetworkHelper makeModelValueWithKey:@"freight_paytype" Model:dic Null:@""];
//            model.avatar = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"avatar" Model:dic Null:@""]];
//            model.msg_cost = [NetworkHelper makeModelValueWithKey:@"msg_cost" Model:dic Null:@""];
//            model.load_time = [NetworkHelper makeModelValueWithKey:@"load_time" Model:dic Null:@""];
//            model.unload_time = [NetworkHelper makeModelValueWithKey:@"unload_time" Model:dic Null:@""];
//            model.coal_type = [NetworkHelper makeModelValueWithKey:@"coal_type" Model:dic Null:@""];
//            model.notes = [NetworkHelper makeModelValueWithKey:@"notes" Model:dic Null:@""];
//            model.pick_address = [NetworkHelper makeModelValueWithKey:@"pick_address" Model:dic Null:@""];
//            model.telephone = [NetworkHelper makeModelValueWithKey:@"telephone" Model:dic Null:@""];
//            return model;
//        }
//            break;
//            
//        case ApiEnumGetTransportInfo://进行中的运单
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            
//            getHisTransportsListModel *model = [[getHisTransportsListModel alloc] init];
//            model.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            model.trans_status = [NetworkHelper makeModelValueWithKey:@"trans_status" Model:dic Null:@""];
//            model.trans_no = [NetworkHelper makeModelValueWithKey:@"trans_no" Model:dic Null:@""];
//            model.contact = [NetworkHelper makeModelValueWithKey:@"contact" Model:dic Null:@""];
//            model.avatar = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"avatar" Model:dic Null:@""]];
//            model.telephone = [NetworkHelper makeModelValueWithKey:@"telephone" Model:dic Null:@""];
//            model.from = [NetworkHelper makeModelValueWithKey:@"from" Model:dic Null:@""];
//            model.to = [NetworkHelper makeModelValueWithKey:@"to" Model:dic Null:@""];
//            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            model.load_cost = [NetworkHelper makeModelValueWithKey:@"load_cost" Model:dic Null:@""];
//            model.unload_cost = [NetworkHelper makeModelValueWithKey:@"unload_cost" Model:dic Null:@""];
//            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            model.grabbed_time = [NetworkHelper makeModelValueWithKey:@"grabbed_time" Model:dic Null:@""];
//            model.coal_type = [NetworkHelper makeModelValueWithKey:@"coal_type" Model:dic Null:@""];
//            
//            return model;
//            
//            //            getTransportInfoModel *model = [[getTransportInfoModel alloc] init];
//            //            model.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            //            model.trans_status = [NetworkHelper makeModelValueWithKey:@"trans_status" Model:dic Null:@""];
//            //            model.trans_no = [NetworkHelper makeModelValueWithKey:@"trans_no" Model:dic Null:@""];
//            //            model.tso_id = [NetworkHelper makeModelValueWithKey:@"tso_id" Model:dic Null:@""];
//            //            model.contact = [NetworkHelper makeModelValueWithKey:@"contact" Model:dic Null:@""];
//            //            model.left_trans = [NetworkHelper makeModelValueWithKey:@"left_trans" Model:dic Null:@""];
//            //            model.from = [NetworkHelper makeModelValueWithKey:@"from" Model:dic Null:@""];
//            //            model.to = [NetworkHelper makeModelValueWithKey:@"to" Model:dic Null:@""];
//            //            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            //            model.load_cost = [NetworkHelper makeModelValueWithKey:@"load_cost" Model:dic Null:@""];
//            //            model.unload_cost = [NetworkHelper makeModelValueWithKey:@"unload_cost" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.freight_paytype = [NetworkHelper makeModelValueWithKey:@"freight_paytype" Model:dic Null:@""];
//            //            model.avatar = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"avatar" Model:dic Null:@""]];
//            //            model.msg_cost = [NetworkHelper makeModelValueWithKey:@"msg_cost" Model:dic Null:@""];
//            //            model.load_time = [NetworkHelper makeModelValueWithKey:@"load_time" Model:dic Null:@""];
//            //            model.unload_time = [NetworkHelper makeModelValueWithKey:@"unload_time" Model:dic Null:@""];
//            //            model.coal_type = [NetworkHelper makeModelValueWithKey:@"coal_type" Model:dic Null:@""];
//            //            model.notes = [NetworkHelper makeModelValueWithKey:@"notes" Model:dic Null:@""];
//            //            model.pick_address = [NetworkHelper makeModelValueWithKey:@"pick_address" Model:dic Null:@""];
//            //            model.telephone = [NetworkHelper makeModelValueWithKey:@"telephone" Model:dic Null:@""];
//            //            return model;
//        }
//            break;
//        case ApiEnumCancelTransports ://取消运单
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//        }
//            break;
//        case     ApiEnumContactOwner ://联系货主
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//        }
//            break;
//        case      ApiEnumGetHisTransportList ://历史运单
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            getHisTransportsListModel *model = [[getHisTransportsListModel alloc] init];
//            model.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            model.trans_status = [NetworkHelper makeModelValueWithKey:@"trans_status" Model:dic Null:@""];
//            model.trans_no = [NetworkHelper makeModelValueWithKey:@"trans_no" Model:dic Null:@""];
//            model.contact = [NetworkHelper makeModelValueWithKey:@"contact" Model:dic Null:@""];
//            model.avatar = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"avatar" Model:dic Null:@""]];
//            model.telephone = [NetworkHelper makeModelValueWithKey:@"telephone" Model:dic Null:@""];
//            model.from = [NetworkHelper makeModelValueWithKey:@"from" Model:dic Null:@""];
//            model.to = [NetworkHelper makeModelValueWithKey:@"to" Model:dic Null:@""];
//            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            model.load_cost = [NetworkHelper makeModelValueWithKey:@"load_cost" Model:dic Null:@""];
//            model.unload_cost = [NetworkHelper makeModelValueWithKey:@"unload_cost" Model:dic Null:@""];
//            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            model.grabbed_time = [NetworkHelper makeModelValueWithKey:@"grabbed_time" Model:dic Null:@""];
//            model.coal_type = [NetworkHelper makeModelValueWithKey:@"coal_type" Model:dic Null:@""];
//            
//            return model;
//            
//        }
//            break;
//            
//        case      ApiEnumGetHisTransportInfo ://历史运单详情
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            getHisTransportInfoModel *model = [[getHisTransportInfoModel alloc] init];
//            model.trans_status = [NetworkHelper makeModelValueWithKey:@"trans_status" Model:dic Null:@""];
//            model.trans_no = [NetworkHelper makeModelValueWithKey:@"trans_no" Model:dic Null:@""];
//            model.contact = [NetworkHelper makeModelValueWithKey:@"contact" Model:dic Null:@""];
//            model.avatar = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"avatar" Model:dic Null:@""]];
//            model.telephone = [NetworkHelper makeModelValueWithKey:@"telephone" Model:dic Null:@""];
//            model.from = [NetworkHelper makeModelValueWithKey:@"from" Model:dic Null:@""];
//            model.to = [NetworkHelper makeModelValueWithKey:@"to" Model:dic Null:@""];
//            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            model.load_cost = [NetworkHelper makeModelValueWithKey:@"load_cost" Model:dic Null:@""];
//            model.unload_cost = [NetworkHelper makeModelValueWithKey:@"unload_cost" Model:dic Null:@""];
//            model.coal_type = [NetworkHelper makeModelValueWithKey:@"coal_type" Model:dic Null:@""];
//            model.freight_paytype = [NetworkHelper makeModelValueWithKey:@"freight_paytype" Model:dic Null:@""];
//            model.msg_cost = [NetworkHelper makeModelValueWithKey:@"msg_cost" Model:dic Null:@""];
//            model.load_time = [NetworkHelper makeModelValueWithKey:@"load_time" Model:dic Null:@""];
//            model.unload_time = [NetworkHelper makeModelValueWithKey:@"unload_time" Model:dic Null:@""];
//            model.notes = [NetworkHelper makeModelValueWithKey:@"notes" Model:dic Null:@""];
//            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            model.pick_address = [NetworkHelper makeModelValueWithKey:@"pick_address" Model:dic Null:@""];
//            return model;
//            
//        }
//            break;
//            
//            
//        case       ApiEnumGetRouteList ://订阅路线列表
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            RouteListModel *model = [[RouteListModel alloc] init];
//            model.route_id = [NetworkHelper makeModelValueWithKey:@"route_id" Model:dic Null:@""];
//            model.from = [NetworkHelper makeModelValueWithKey:@"from" Model:dic Null:@""];
//            model.to = [NetworkHelper makeModelValueWithKey:@"to" Model:dic Null:@""];
//            
//            return model;
//            
//        }
//            break;
//            
//        case          ApiEnumTransportsGetSpecialLineList ://获取专线列表
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            getSpecialLineListModel *model = [[getSpecialLineListModel alloc] init];
//            model.line_id = [NetworkHelper makeModelValueWithKey:@"line_id" Model:dic Null:@""];
//            model.line_name = [NetworkHelper makeModelValueWithKey:@"line_name" Model:dic Null:@""];
//            model.pic_url = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"pic_url" Model:dic Null:@""]];
//            
//            return model;
//            
//        }
//            break;
//            
//        case       ApiEnumUploadCheckPhoto ://上传图片
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            uploadCheckPhotoModel *model = [[uploadCheckPhotoModel alloc] init];
//            model.paper_id = [NetworkHelper makeModelValueWithKey:@"paper_id" Model:dic Null:@""];
//            model.paper_path = [NetworkHelper makeModelValueWithKey:@"paper_path" Model:dic Null:@""];
//            
//            return model;
//            
//        }
//            break;
//            
//        case     ApiEnumAddCheckInfo ://提交审核
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            
//            return dic;
//            
//        }
//            break;
//            
//        case       ApiEnumGetDistrict ://获取省市县
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            subacityModel *model = [[subacityModel alloc] init];
//            model.city_id = [NetworkHelper makeModelValueWithKey:@"city_id" Model:dic Null:@""];
//            model.city_name = [NetworkHelper makeModelValueWithKey:@"city_name" Model:dic Null:@""];
//            model.level = [NetworkHelper makeModelValueWithKey:@"level" Model:dic Null:@""];
//            model.upid = [NetworkHelper makeModelValueWithKey:@"upid" Model:dic Null:@""];
//            return model;
//            
//        }
//            break;
//            
//            
//            //        case ApiEnumOrderAdd://提交订单
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumMyOrdersList://我的订单列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            MyOrdersListModel *model = [[MyOrdersListModel alloc] init];
//            //            model.tdo_id = [NetworkHelper makeModelValueWithKey:@"tdo_id" Model:dic Null:@""];
//            //            model.tdo_no = [NetworkHelper makeModelValueWithKey:@"tdo_no" Model:dic Null:@""];
//            //            model.product_id = [NetworkHelper makeModelValueWithKey:@"product_id" Model:dic Null:@""];
//            //            model.product_name = [NetworkHelper makeModelValueWithKey:@"product_name" Model:dic Null:@""];
//            //            model.price = [NetworkHelper makeModelValueWithKey:@"price" Model:dic Null:@""];
//            //            model.total = [NetworkHelper makeModelValueWithKey:@"total" Model:dic Null:@""];
//            //            model.cost = [NetworkHelper makeModelValueWithKey:@"cost" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.calorific_value = [NetworkHelper makeModelValueWithKey:@"calorific_value" Model:dic Null:@""];
//            //            model.transport = [NetworkHelper makeModelValueWithKey:@"transport" Model:dic Null:@""];
//            //            model.done = [NetworkHelper makeModelValueWithKey:@"done" Model:dic Null:@""];
//            //            model.process = [NetworkHelper makeModelValueWithKey:@"process" Model:dic Null:@""];
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumOrderInfo://订单详情
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            OrderInfoModel *model = [[OrderInfoModel alloc] init];
//            //            model.tdo_id = [NetworkHelper makeModelValueWithKey:@"tdo_id" Model:dic Null:@""];
//            //            model.tdo_no = [NetworkHelper makeModelValueWithKey:@"tdo_no" Model:dic Null:@""];
//            //            model.product_id = [NetworkHelper makeModelValueWithKey:@"product_id" Model:dic Null:@""];
//            //            model.product_name = [NetworkHelper makeModelValueWithKey:@"product_name" Model:dic Null:@""];
//            //            model.price = [NetworkHelper makeModelValueWithKey:@"price" Model:dic Null:@""];
//            //            model.total = [NetworkHelper makeModelValueWithKey:@"total" Model:dic Null:@""];
//            //            model.cost = [NetworkHelper makeModelValueWithKey:@"cost" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.calorific_value = [NetworkHelper makeModelValueWithKey:@"calorific_value" Model:dic Null:@""];
//            //            model.transport = [NetworkHelper makeModelValueWithKey:@"transport" Model:dic Null:@""];
//            //            model.done = [NetworkHelper makeModelValueWithKey:@"done" Model:dic Null:@""];
//            //            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            //
//            //            model.notes = [NetworkHelper makeModelValueWithKey:@"notes" Model:dic Null:@""];
//            //
//            //            model.value = [NetworkHelper makeModelValueWithKey:@"value" Model:dic Null:@""];
//            //
//            //
//            //            model.unload_time = [NetworkHelper makeModelValueWithKey:@"unload_time" Model:dic Null:@""];
//            //            model.unload_cost = [NetworkHelper makeModelValueWithKey:@"unload_cost" Model:dic Null:@""];
//            //
//            //            model.unload_contact = [NetworkHelper makeModelValueWithKey:@"unload_contact" Model:dic Null:@""];
//            //
//            //            model.unload_telephone = [NetworkHelper makeModelValueWithKey:@"unload_telephone" Model:dic Null:@""];
//            //            model.ra_address = [NetworkHelper makeModelValueWithKey:@"ra_address" Model:dic Null:@""];
//            //
//            //            model.paytype_name = [NetworkHelper makeModelValueWithKey:@"paytype_name" Model:dic Null:@""];
//            //
//            //            model.ra_contact = [NetworkHelper makeModelValueWithKey:@"ra_contact" Model:dic Null:@""];
//            //
//            //            model.ra_telephone = [NetworkHelper makeModelValueWithKey:@"ra_telephone" Model:dic Null:@""];
//            //            model.unload_info = [NetworkHelper makeModelValueWithKey:@"unload_info" Model:dic Null:@""];
//            //
//            //            model.audit_notes = [NetworkHelper makeModelValueWithKey:@"audit_notes" Model:dic Null:@""];
//            //
//            //            model.t_finish_status = [NetworkHelper makeModelValueWithKey:@"t_finish_status" Model:dic Null:@""];
//            //            model.t_ready_status = [NetworkHelper makeModelValueWithKey:@"t_ready_status" Model:dic Null:@""];
//            //
//            //
//            //            model.show_total = [NetworkHelper makeModelValueWithKey:@"show_total" Model:dic Null:@""];
//            //
//            //            model.show_price = [NetworkHelper makeModelValueWithKey:@"show_price" Model:dic Null:@""];
//            //            model.show_freight = [NetworkHelper makeModelValueWithKey:@"show_freight" Model:dic Null:@""];
//            //            model.total_price = [NetworkHelper makeModelValueWithKey:@"total_price" Model:dic Null:@""];
//            //
//            //            model.bystages = [NetworkHelper makeModelValueWithKey:@"bystages" Model:dic Null:@""];
//            //
//            //            model.assay_sheet = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"assay_sheet" Model:dic Null:@""]];
//            //            model.acceptance = [NetworkHelper makeModelValueWithKey:@"acceptance" Model:dic Null:@""];
//            //
//            ////            NSArray *array = [NetworkHelper makeModelValueWithKey:@"order_notes" Model:dic Null:@""];
//            ////            model.order_notes = [NSMutableArray array];
//            ////            for (NSDictionary *mydic in array) {
//            ////                [model.order_notes addObject:[NetworkHelper makeModelValueWithKey:@"notes" Model:mydic Null:@""]];
//            ////            }
//            //
//            //
//            //            return model;
//            //
//            //        }
//            //
//            //
//            //
//            //        case ApiEnumLogisticsList://物流列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            LogisticsListModel *model = [[LogisticsListModel alloc] init];
//            //            model.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            //            model.trans_no = [NetworkHelper makeModelValueWithKey:@"trans_no" Model:dic Null:@""];
//            //            model.grabbed_time = [NetworkHelper makeModelValueWithKey:@"grabbed_time" Model:dic Null:@""];
//            //            model.done_time = [NetworkHelper makeModelValueWithKey:@"done_time" Model:dic Null:@""];
//            //            model.trans_status = [NetworkHelper makeModelValueWithKey:@"trans_status" Model:dic Null:@""];
//            //            model.truck_id = [NetworkHelper makeModelValueWithKey:@"truck_id" Model:dic Null:@""];
//            //            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            //            model.is_img = [NetworkHelper makeModelValueWithKey:@"is_img" Model:dic Null:@""];
//            //            model.is_evaluate = [NetworkHelper makeModelValueWithKey:@"is_evaluate" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumOrderDoneList://一键买煤
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            OrderDoneListModel *model = [[OrderDoneListModel alloc] init];
//            //            model.user_id = [NetworkHelper makeModelValueWithKey:@"user_id" Model:dic Null:@""];
//            //            model.unload_time = [NetworkHelper makeModelValueWithKey:@"unload_time" Model:dic Null:@""];
//            //            model.unload_telephone = [NetworkHelper makeModelValueWithKey:@"unload_telephone" Model:dic Null:@""];
//            //            model.unload_cost = [NetworkHelper makeModelValueWithKey:@"unload_cost" Model:dic Null:@""];
//            //            model.unload_contact = [NetworkHelper makeModelValueWithKey:@"unload_contact" Model:dic Null:@""];
//            //            model.unit = [NetworkHelper makeModelValueWithKey:@"unit" Model:dic Null:@""];
//            //            model.total_price = [NetworkHelper makeModelValueWithKey:@"total_price" Model:dic Null:@""];
//            //
//            //            model.ra_contact = [NetworkHelper makeModelValueWithKey:@"ra_contact" Model:dic Null:@""];
//            //            model.ra_id = [NetworkHelper makeModelValueWithKey:@"ra_id" Model:dic Null:@""];
//            //            model.ra_telephone = [NetworkHelper makeModelValueWithKey:@"ra_telephone" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.tdo_id = [NetworkHelper makeModelValueWithKey:@"tdo_id" Model:dic Null:@""];
//            //            model.tdo_no = [NetworkHelper makeModelValueWithKey:@"tdo_no" Model:dic Null:@""];
//            //            model.total = [NetworkHelper makeModelValueWithKey:@"total" Model:dic Null:@""];
//            //
//            //
//            //            model.freight_paytype = [NetworkHelper makeModelValueWithKey:@"freight_paytype" Model:dic Null:@""];
//            //            model.notes = [NetworkHelper makeModelValueWithKey:@"notes" Model:dic Null:@""];
//            //            model.price = [NetworkHelper makeModelValueWithKey:@"price" Model:dic Null:@""];
//            //            model.payment_id = [NetworkHelper makeModelValueWithKey:@"payment_id" Model:dic Null:@""];
//            //            model.product_id = [NetworkHelper makeModelValueWithKey:@"product_id" Model:dic Null:@""];
//            //            model.product_name = [NetworkHelper makeModelValueWithKey:@"product_name" Model:dic Null:@""];
//            //            model.ra_address = [NetworkHelper makeModelValueWithKey:@"ra_address" Model:dic Null:@""];
//            //
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.audit_by = [NetworkHelper makeModelValueWithKey:@"audit_by" Model:dic Null:@""];
//            //            model.ra_telephone = [NetworkHelper makeModelValueWithKey:@"ra_telephone" Model:dic Null:@""];
//            //            model.audit_notes = [NetworkHelper makeModelValueWithKey:@"audit_notes" Model:dic Null:@""];
//            //            model.calorific_value = [NetworkHelper makeModelValueWithKey:@"calorific_value" Model:dic Null:@""];
//            //            model.cost = [NetworkHelper makeModelValueWithKey:@"cost" Model:dic Null:@""];
//            //            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            //            model.process = [NetworkHelper makeModelValueWithKey:@"process" Model:dic Null:@""];
//            //            model.bystages = [NetworkHelper makeModelValueWithKey:@"bystages" Model:dic Null:@""];
//            //            model.assay_sheet = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"assay_sheet" Model:dic Null:@""]];
//            //            model.descriptionString = [NetworkHelper makeModelValueWithKey:@"descriptionString" Model:dic Null:@""];
//            //            model.acceptance = [NetworkHelper makeModelValueWithKey:@"acceptance" Model:dic Null:@""];
//            //            return model;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumClientManager://我的订单列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            ClientManagerModel *model = [[ClientManagerModel alloc] init];
//            //            model.avatar = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"avatar" Model:dic Null:@""]];
//            //            model.ceil_phone = [NetworkHelper makeModelValueWithKey:@"ceil_phone" Model:dic Null:@""];
//            //            model.employee_id = [NetworkHelper makeModelValueWithKey:@"employee_id" Model:dic Null:@""];
//            //            model.employee_name = [NetworkHelper makeModelValueWithKey:@"employee_name" Model:dic Null:@""];
//            //            model.precinct = [NetworkHelper makeModelValueWithKey:@"precinct" Model:dic Null:@""];
//            //            model.role_name = [NetworkHelper makeModelValueWithKey:@"role_name" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumWaybillList://运单列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            WaybillListModel *model = [[WaybillListModel alloc] init];
//            //            model.shorter_form_load = [NetworkHelper makeModelValueWithKey:@"shorter_form_load" Model:dic Null:@""];
//            //            model.shorter_form_unload = [NetworkHelper makeModelValueWithKey:@"shorter_form_unload" Model:dic Null:@""];
//            //            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            //            model.total = [NetworkHelper makeModelValueWithKey:@"total" Model:dic Null:@""];
//            //            model.contact = [NetworkHelper makeModelValueWithKey:@"contact" Model:dic Null:@""];
//            //            model.telephone = [NetworkHelper makeModelValueWithKey:@"telephone" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.tso_id = [NetworkHelper makeModelValueWithKey:@"tso_id" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumSucceedTranspor://抢单
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //
//            //        case ApiEnumHistoryList://运单历史列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            HistoryListModel *model = [[HistoryListModel alloc] init];
//            //            model.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            //            model.shorter_form_load = [NetworkHelper makeModelValueWithKey:@"shorter_form_load" Model:dic Null:@""];
//            //            model.shorter_form_unload = [NetworkHelper makeModelValueWithKey:@"shorter_form_unload" Model:dic Null:@""];
//            //            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            //            model.trans_status = [NetworkHelper makeModelValueWithKey:@"trans_status" Model:dic Null:@""];
//            //            model.arrive_time = [NetworkHelper makeModelValueWithKey:@"arrive_time" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //
//            //
//            
//        case     ApiEnumAddRoute ://添加路线
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//        }
//            break;
//            
//        case       ApiEnumDeleteRoute://删除路线
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//        }
//            break;
//            
//        case      ApiEnumGetBankCardsList ://银行卡列表
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            BankListModel *model = [[BankListModel alloc] init];
//            model.bc_id = [NetworkHelper makeModelValueWithKey:@"bc_id" Model:dic Null:@""];
//            model.card_owner = [NetworkHelper makeModelValueWithKey:@"card_owner" Model:dic Null:@""];
//            model.bc_no = [NetworkHelper makeModelValueWithKey:@"bc_no" Model:dic Null:@""];
//            model.bc_bank_of_deposit = [NetworkHelper makeModelValueWithKey:@"bc_bank_of_deposit" Model:dic Null:@""];
//            return model;
//            
//        }
//            break;
//        case      ApiEnumAddBankCard ://添加银行卡
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//        }
//            break;
//        case      ApiEnumDeleteBankCard ://删除银行卡
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//        }
//            break;
//        case        ApiEnumCheckBankCardNum ://校验银行
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            CheckBankModel *model = [[CheckBankModel alloc] init];
//            model.cardtype = [NetworkHelper makeModelValueWithKey:@"cardtype" Model:dic Null:@""];
//            model.cardlength = [NetworkHelper makeModelValueWithKey:@"cardlength" Model:dic Null:@""];
//            model.cardprefixnum = [NetworkHelper makeModelValueWithKey:@"cardprefixnum" Model:dic Null:@""];
//            model.cardname = [NetworkHelper makeModelValueWithKey:@"cardname" Model:dic Null:@""];
//            model.bankname = [NetworkHelper makeModelValueWithKey:@"bankname" Model:dic Null:@""];
//            model.banknum = [NetworkHelper makeModelValueWithKey:@"banknum" Model:dic Null:@""];
//            
//            
//            return model;
//            
//        }
//            break;
//            
//        case        ApiEnumCheckInfo ://身份认证页面(货主 司机通用)
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            checkInfoModel *model = [[checkInfoModel alloc] init];
//            model.u_status = [NetworkHelper makeModelValueWithKey:@"u_status" Model:dic Null:@""];
//            model.realname = [NetworkHelper makeModelValueWithKey:@"realname" Model:dic Null:@""];
//            model.identity_no = [NetworkHelper makeModelValueWithKey:@"identity_no" Model:dic Null:@""];
//            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            model.papers = [NetworkHelper makeModelValueWithKey:@"papers" Model:dic Null:@""];
//            model.faild_reason = [NetworkHelper makeModelValueWithKey:@"faild_reason" Model:dic Null:@""];
//            model.company_name = [NetworkHelper makeModelValueWithKey:@"company_name" Model:dic Null:@""];
//            
//            NSMutableArray *array = [NSMutableArray array];
//            
//            for (NSDictionary *dic in model.papers) {
//                
//                checkInfoPapersModel *model = [[checkInfoPapersModel alloc] init];
//                
//                model.paper_id = [NetworkHelper makeModelValueWithKey:@"paper_id" Model:dic Null:@""];
//                model.ptype_id = [NetworkHelper makeModelValueWithKey:@"ptype_id" Model:dic Null:@""];
//                model.paper_path = [NetworkHelper makeModelValueWithKey:@"paper_path" Model:dic Null:@""];
//                model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//                [array addObject:model];
//                
//            }
//            
//            model.papers = array;
//            
//            
//            return model;
//            
//            
//        }
//            break;
//            
//            
//            //        case ApiEnumOrderAdd://提交订单
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumMyOrdersList://我的订单列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            MyOrdersListModel *model = [[MyOrdersListModel alloc] init];
//            //            model.tdo_id = [NetworkHelper makeModelValueWithKey:@"tdo_id" Model:dic Null:@""];
//            //            model.tdo_no = [NetworkHelper makeModelValueWithKey:@"tdo_no" Model:dic Null:@""];
//            //            model.product_id = [NetworkHelper makeModelValueWithKey:@"product_id" Model:dic Null:@""];
//            //            model.product_name = [NetworkHelper makeModelValueWithKey:@"product_name" Model:dic Null:@""];
//            //            model.price = [NetworkHelper makeModelValueWithKey:@"price" Model:dic Null:@""];
//            //            model.total = [NetworkHelper makeModelValueWithKey:@"total" Model:dic Null:@""];
//            //            model.cost = [NetworkHelper makeModelValueWithKey:@"cost" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.calorific_value = [NetworkHelper makeModelValueWithKey:@"calorific_value" Model:dic Null:@""];
//            //            model.transport = [NetworkHelper makeModelValueWithKey:@"transport" Model:dic Null:@""];
//            //            model.done = [NetworkHelper makeModelValueWithKey:@"done" Model:dic Null:@""];
//            //            model.process = [NetworkHelper makeModelValueWithKey:@"process" Model:dic Null:@""];
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumOrderInfo://订单详情
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            OrderInfoModel *model = [[OrderInfoModel alloc] init];
//            //            model.tdo_id = [NetworkHelper makeModelValueWithKey:@"tdo_id" Model:dic Null:@""];
//            //            model.tdo_no = [NetworkHelper makeModelValueWithKey:@"tdo_no" Model:dic Null:@""];
//            //            model.product_id = [NetworkHelper makeModelValueWithKey:@"product_id" Model:dic Null:@""];
//            //            model.product_name = [NetworkHelper makeModelValueWithKey:@"product_name" Model:dic Null:@""];
//            //            model.price = [NetworkHelper makeModelValueWithKey:@"price" Model:dic Null:@""];
//            //            model.total = [NetworkHelper makeModelValueWithKey:@"total" Model:dic Null:@""];
//            //            model.cost = [NetworkHelper makeModelValueWithKey:@"cost" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.calorific_value = [NetworkHelper makeModelValueWithKey:@"calorific_value" Model:dic Null:@""];
//            //            model.transport = [NetworkHelper makeModelValueWithKey:@"transport" Model:dic Null:@""];
//            //            model.done = [NetworkHelper makeModelValueWithKey:@"done" Model:dic Null:@""];
//            //            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            //
//            //            model.notes = [NetworkHelper makeModelValueWithKey:@"notes" Model:dic Null:@""];
//            //
//            //            model.value = [NetworkHelper makeModelValueWithKey:@"value" Model:dic Null:@""];
//            //
//            //
//            //            model.unload_time = [NetworkHelper makeModelValueWithKey:@"unload_time" Model:dic Null:@""];
//            //            model.unload_cost = [NetworkHelper makeModelValueWithKey:@"unload_cost" Model:dic Null:@""];
//            //
//            //            model.unload_contact = [NetworkHelper makeModelValueWithKey:@"unload_contact" Model:dic Null:@""];
//            //
//            //            model.unload_telephone = [NetworkHelper makeModelValueWithKey:@"unload_telephone" Model:dic Null:@""];
//            //            model.ra_address = [NetworkHelper makeModelValueWithKey:@"ra_address" Model:dic Null:@""];
//            //
//            //            model.paytype_name = [NetworkHelper makeModelValueWithKey:@"paytype_name" Model:dic Null:@""];
//            //
//            //            model.ra_contact = [NetworkHelper makeModelValueWithKey:@"ra_contact" Model:dic Null:@""];
//            //
//            //            model.ra_telephone = [NetworkHelper makeModelValueWithKey:@"ra_telephone" Model:dic Null:@""];
//            //            model.unload_info = [NetworkHelper makeModelValueWithKey:@"unload_info" Model:dic Null:@""];
//            //
//            //            model.audit_notes = [NetworkHelper makeModelValueWithKey:@"audit_notes" Model:dic Null:@""];
//            //
//            //            model.t_finish_status = [NetworkHelper makeModelValueWithKey:@"t_finish_status" Model:dic Null:@""];
//            //            model.t_ready_status = [NetworkHelper makeModelValueWithKey:@"t_ready_status" Model:dic Null:@""];
//            //
//            //
//            //            model.show_total = [NetworkHelper makeModelValueWithKey:@"show_total" Model:dic Null:@""];
//            //
//            //            model.show_price = [NetworkHelper makeModelValueWithKey:@"show_price" Model:dic Null:@""];
//            //            model.show_freight = [NetworkHelper makeModelValueWithKey:@"show_freight" Model:dic Null:@""];
//            //            model.total_price = [NetworkHelper makeModelValueWithKey:@"total_price" Model:dic Null:@""];
//            //
//            //            model.bystages = [NetworkHelper makeModelValueWithKey:@"bystages" Model:dic Null:@""];
//            //
//            //            model.assay_sheet = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"assay_sheet" Model:dic Null:@""]];
//            //            model.acceptance = [NetworkHelper makeModelValueWithKey:@"acceptance" Model:dic Null:@""];
//            //
//            ////            NSArray *array = [NetworkHelper makeModelValueWithKey:@"order_notes" Model:dic Null:@""];
//            ////            model.order_notes = [NSMutableArray array];
//            ////            for (NSDictionary *mydic in array) {
//            ////                [model.order_notes addObject:[NetworkHelper makeModelValueWithKey:@"notes" Model:mydic Null:@""]];
//            ////            }
//            //
//            //
//            //            return model;
//            //
//            //        }
//            //
//            //
//            //
//            //        case ApiEnumLogisticsList://物流列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            LogisticsListModel *model = [[LogisticsListModel alloc] init];
//            //            model.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            //            model.trans_no = [NetworkHelper makeModelValueWithKey:@"trans_no" Model:dic Null:@""];
//            //            model.grabbed_time = [NetworkHelper makeModelValueWithKey:@"grabbed_time" Model:dic Null:@""];
//            //            model.done_time = [NetworkHelper makeModelValueWithKey:@"done_time" Model:dic Null:@""];
//            //            model.trans_status = [NetworkHelper makeModelValueWithKey:@"trans_status" Model:dic Null:@""];
//            //            model.truck_id = [NetworkHelper makeModelValueWithKey:@"truck_id" Model:dic Null:@""];
//            //            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            //            model.is_img = [NetworkHelper makeModelValueWithKey:@"is_img" Model:dic Null:@""];
//            //            model.is_evaluate = [NetworkHelper makeModelValueWithKey:@"is_evaluate" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumOrderDoneList://一键买煤
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            OrderDoneListModel *model = [[OrderDoneListModel alloc] init];
//            //            model.user_id = [NetworkHelper makeModelValueWithKey:@"user_id" Model:dic Null:@""];
//            //            model.unload_time = [NetworkHelper makeModelValueWithKey:@"unload_time" Model:dic Null:@""];
//            //            model.unload_telephone = [NetworkHelper makeModelValueWithKey:@"unload_telephone" Model:dic Null:@""];
//            //            model.unload_cost = [NetworkHelper makeModelValueWithKey:@"unload_cost" Model:dic Null:@""];
//            //            model.unload_contact = [NetworkHelper makeModelValueWithKey:@"unload_contact" Model:dic Null:@""];
//            //            model.unit = [NetworkHelper makeModelValueWithKey:@"unit" Model:dic Null:@""];
//            //            model.total_price = [NetworkHelper makeModelValueWithKey:@"total_price" Model:dic Null:@""];
//            //
//            //            model.ra_contact = [NetworkHelper makeModelValueWithKey:@"ra_contact" Model:dic Null:@""];
//            //            model.ra_id = [NetworkHelper makeModelValueWithKey:@"ra_id" Model:dic Null:@""];
//            //            model.ra_telephone = [NetworkHelper makeModelValueWithKey:@"ra_telephone" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.tdo_id = [NetworkHelper makeModelValueWithKey:@"tdo_id" Model:dic Null:@""];
//            //            model.tdo_no = [NetworkHelper makeModelValueWithKey:@"tdo_no" Model:dic Null:@""];
//            //            model.total = [NetworkHelper makeModelValueWithKey:@"total" Model:dic Null:@""];
//            //
//            //
//            //            model.freight_paytype = [NetworkHelper makeModelValueWithKey:@"freight_paytype" Model:dic Null:@""];
//            //            model.notes = [NetworkHelper makeModelValueWithKey:@"notes" Model:dic Null:@""];
//            //            model.price = [NetworkHelper makeModelValueWithKey:@"price" Model:dic Null:@""];
//            //            model.payment_id = [NetworkHelper makeModelValueWithKey:@"payment_id" Model:dic Null:@""];
//            //            model.product_id = [NetworkHelper makeModelValueWithKey:@"product_id" Model:dic Null:@""];
//            //            model.product_name = [NetworkHelper makeModelValueWithKey:@"product_name" Model:dic Null:@""];
//            //            model.ra_address = [NetworkHelper makeModelValueWithKey:@"ra_address" Model:dic Null:@""];
//            //
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.audit_by = [NetworkHelper makeModelValueWithKey:@"audit_by" Model:dic Null:@""];
//            //            model.ra_telephone = [NetworkHelper makeModelValueWithKey:@"ra_telephone" Model:dic Null:@""];
//            //            model.audit_notes = [NetworkHelper makeModelValueWithKey:@"audit_notes" Model:dic Null:@""];
//            //            model.calorific_value = [NetworkHelper makeModelValueWithKey:@"calorific_value" Model:dic Null:@""];
//            //            model.cost = [NetworkHelper makeModelValueWithKey:@"cost" Model:dic Null:@""];
//            //            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            //            model.process = [NetworkHelper makeModelValueWithKey:@"process" Model:dic Null:@""];
//            //            model.bystages = [NetworkHelper makeModelValueWithKey:@"bystages" Model:dic Null:@""];
//            //            model.assay_sheet = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"assay_sheet" Model:dic Null:@""]];
//            //            model.descriptionString = [NetworkHelper makeModelValueWithKey:@"descriptionString" Model:dic Null:@""];
//            //            model.acceptance = [NetworkHelper makeModelValueWithKey:@"acceptance" Model:dic Null:@""];
//            //            return model;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumClientManager://我的订单列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            ClientManagerModel *model = [[ClientManagerModel alloc] init];
//            //            model.avatar = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"avatar" Model:dic Null:@""]];
//            //            model.ceil_phone = [NetworkHelper makeModelValueWithKey:@"ceil_phone" Model:dic Null:@""];
//            //            model.employee_id = [NetworkHelper makeModelValueWithKey:@"employee_id" Model:dic Null:@""];
//            //            model.employee_name = [NetworkHelper makeModelValueWithKey:@"employee_name" Model:dic Null:@""];
//            //            model.precinct = [NetworkHelper makeModelValueWithKey:@"precinct" Model:dic Null:@""];
//            //            model.role_name = [NetworkHelper makeModelValueWithKey:@"role_name" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumWaybillList://运单列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            WaybillListModel *model = [[WaybillListModel alloc] init];
//            //            model.shorter_form_load = [NetworkHelper makeModelValueWithKey:@"shorter_form_load" Model:dic Null:@""];
//            //            model.shorter_form_unload = [NetworkHelper makeModelValueWithKey:@"shorter_form_unload" Model:dic Null:@""];
//            //            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            //            model.total = [NetworkHelper makeModelValueWithKey:@"total" Model:dic Null:@""];
//            //            model.contact = [NetworkHelper makeModelValueWithKey:@"contact" Model:dic Null:@""];
//            //            model.telephone = [NetworkHelper makeModelValueWithKey:@"telephone" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.tso_id = [NetworkHelper makeModelValueWithKey:@"tso_id" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumSucceedTranspor://抢单
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //
//            //        case ApiEnumHistoryList://运单历史列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            HistoryListModel *model = [[HistoryListModel alloc] init];
//            //            model.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            //            model.shorter_form_load = [NetworkHelper makeModelValueWithKey:@"shorter_form_load" Model:dic Null:@""];
//            //            model.shorter_form_unload = [NetworkHelper makeModelValueWithKey:@"shorter_form_unload" Model:dic Null:@""];
//            //            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            //            model.trans_status = [NetworkHelper makeModelValueWithKey:@"trans_status" Model:dic Null:@""];
//            //            model.arrive_time = [NetworkHelper makeModelValueWithKey:@"arrive_time" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //
//            //
//            
//        case ApiEnumFeedback://意见反馈
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//        }
//            break;
//            
//        case ApiEnumGetAddressList://收货地址列表
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            getAddressListModel *model = [[getAddressListModel alloc] init];
//            model.addr_id = [NetworkHelper makeModelValueWithKey:@"addr_id" Model:dic Null:@""];
//            model.district = [NetworkHelper makeModelValueWithKey:@"district" Model:dic Null:@""];
//            model.address = [NetworkHelper makeModelValueWithKey:@"address" Model:dic Null:@""];
//            model.addr_status = [NetworkHelper makeModelValueWithKey:@"addr_status" Model:dic Null:@""];
//            
//            model.city = [NetworkHelper makeModelValueWithKey:@"city" Model:dic Null:@""];
//            model.province = [NetworkHelper makeModelValueWithKey:@"province" Model:dic Null:@""];
//            model.county = [NetworkHelper makeModelValueWithKey:@"county" Model:dic Null:@""];
//            model.is_line = [NetworkHelper makeModelValueWithKey:@"is_line" Model:dic Null:@""];
//            model.line_id = [NetworkHelper makeModelValueWithKey:@"line_id" Model:dic Null:@""];
//            
//            return model;
//            
//        }
//            //            break;
//            //
//            //        case ApiEnumShippingAddressDel://删除收货地址
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumDefaultAddress://设置默认收货地址
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//        case ApiEnumAddressInfo://收货地址详情
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            addressInfoModel *model = [[addressInfoModel alloc] init];
//            model.province = [NetworkHelper makeModelValueWithKey:@"province" Model:dic Null:@""];
//            model.province_name = [NetworkHelper makeModelValueWithKey:@"province_name" Model:dic Null:@""];
//            model.address = [NetworkHelper makeModelValueWithKey:@"address" Model:dic Null:@""];
//            model.city = [NetworkHelper makeModelValueWithKey:@"city" Model:dic Null:@""];
//            model.city_name = [NetworkHelper makeModelValueWithKey:@"city_name" Model:dic Null:@""];
//            model.county = [NetworkHelper makeModelValueWithKey:@"county" Model:dic Null:@""];
//            model.county_name = [NetworkHelper makeModelValueWithKey:@"county_name" Model:dic Null:@""];
//            
//            
//            return model;
//            
//        }
//            break;
//            //        case ApiEnumShippingAddressAdd://添加收货地址
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //        case ApiEnumShippingAddressModify://修改收货地址
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //        case ApiEnumConsumeConfAdd://提交库存配置
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //        case ApiEnumConsumeHistoryList://消耗历史
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            ConsumeHistoryListModel *model = [[ConsumeHistoryListModel alloc] init];
//            //            model.stock_in = [NetworkHelper makeModelValueWithKey:@"stock_in" Model:dic Null:@""];
//            //            model.day = [NetworkHelper makeModelValueWithKey:@"day" Model:dic Null:@""];
//            //            model.daily_fc = [NetworkHelper makeModelValueWithKey:@"daily_fc" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //        case ApiEnumConsumeHistoryListModify://修改消耗历史
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //        case ApiEnumAutoLogin://自动登录
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            LoginModel *model = [[LoginModel alloc] init];
//            //            model.address = [NetworkHelper makeModelValueWithKey:@"address" Model:dic Null:@""];
//            //            model.area = [NetworkHelper makeModelValueWithKey:@"area" Model:dic Null:@""];
//            //            model.avatar = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"avatar" Model:dic Null:@""]];
//            //            model.ceil_phone = [NetworkHelper makeModelValueWithKey:@"ceil_phone" Model:dic Null:@""];
//            //            model.city = [NetworkHelper makeModelValueWithKey:@"city" Model:dic Null:@""];
//            //            model.company_id = [NetworkHelper makeModelValueWithKey:@"company_id" Model:dic Null:@""];
//            //            model.company_name = [NetworkHelper makeModelValueWithKey:@"company_name" Model:dic Null:@""];
//            //            model.county = [NetworkHelper makeModelValueWithKey:@"county" Model:dic Null:@""];
//            //            model.is_busy = [NetworkHelper makeModelValueWithKey:@"is_busy" Model:dic Null:@""];
//            //            model.manage_owner = [NetworkHelper makeModelValueWithKey:@"manage_owner" Model:dic Null:@""];
//            //            model.paper_no = [NetworkHelper makeModelValueWithKey:@"paper_no" Model:dic Null:@""];
//            //            model.passwd = [NetworkHelper makeModelValueWithKey:@"passwd" Model:dic Null:@""];
//            //            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            //            model.position = [NetworkHelper makeModelValueWithKey:@"position" Model:dic Null:@""];
//            //            model.province = [NetworkHelper makeModelValueWithKey:@"province" Model:dic Null:@""];
//            //            model.realname = [NetworkHelper makeModelValueWithKey:@"realname" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.unread_res = [NetworkHelper makeModelValueWithKey:@"unread_res" Model:dic Null:@""];
//            //            model.user_id = [NetworkHelper makeModelValueWithKey:@"user_id" Model:dic Null:@""];
//            //            model.utype_id = [NetworkHelper makeModelValueWithKey:@"utype_id" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //        case ApiEnumAudiInfo://返回审核信息
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            AudiInfoModel *model = [[AudiInfoModel alloc] init];
//            //            model.user_id = [NetworkHelper makeModelValueWithKey:@"user_id" Model:dic Null:@""];
//            //            model.realname = [NetworkHelper makeModelValueWithKey:@"realname" Model:dic Null:@""];
//            //            model.utype_id = [NetworkHelper makeModelValueWithKey:@"utype_id" Model:dic Null:@""];
//            //            model.company_name = [NetworkHelper makeModelValueWithKey:@"company_name" Model:dic Null:@""];
//            //            model.paper_no = [NetworkHelper makeModelValueWithKey:@"paper_no" Model:dic Null:@""];
//            //            model.identity = [NetworkHelper makeModelValueWithKey:@"identity" Model:dic Null:@""];
//            //            model.business = [NetworkHelper makeModelValueWithKey:@"business" Model:dic Null:@""];
//            //            model.driving = [NetworkHelper makeModelValueWithKey:@"driving" Model:dic Null:@""];
//            //            model.vehicle = [NetworkHelper makeModelValueWithKey:@"vehicle" Model:dic Null:@""];
//            //            model.operate = [NetworkHelper makeModelValueWithKey:@"operate" Model:dic Null:@""];
//            //            model.address = [NetworkHelper makeModelValueWithKey:@"address" Model:dic Null:@""];
//            //            model.position = [NetworkHelper makeModelValueWithKey:@"position" Model:dic Null:@""];
//            //            model.city = [NetworkHelper makeModelValueWithKey:@"city" Model:dic Null:@""];
//            //            model.province = [NetworkHelper makeModelValueWithKey:@"province" Model:dic Null:@""];
//            //            model.county = [NetworkHelper makeModelValueWithKey:@"county" Model:dic Null:@""];
//            //            model.manage_phone = [NetworkHelper makeModelValueWithKey:@"manage_phone" Model:dic Null:@""];
//            //            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            //
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.notes = [NetworkHelper makeModelValueWithKey:@"notes" Model:dic Null:@""];
//            //
//            //            model.province_name = [NetworkHelper makeModelValueWithKey:@"province_name" Model:dic Null:@""];
//            //            model.city_name = [NetworkHelper makeModelValueWithKey:@"city_name" Model:dic Null:@""];
//            //            model.county_name = [NetworkHelper makeModelValueWithKey:@"county_name" Model:dic Null:@""];
//            //            model.province_id = [NetworkHelper makeModelValueWithKey:@"province_id" Model:dic Null:@""];
//            //            model.city_id = [NetworkHelper makeModelValueWithKey:@"city_id" Model:dic Null:@""];
//            //            model.county_id = [NetworkHelper makeModelValueWithKey:@"county_id" Model:dic Null:@""];
//            //
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumCheckAuditImg://返回审核图片信息
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            CheckAuditImgModel *model = [[CheckAuditImgModel alloc] init];
//            //            model.identity = [NetworkHelper makeModelValueWithKey:@"identity" Model:dic Null:@""];
//            //            model.business = [NetworkHelper makeModelValueWithKey:@"business" Model:dic Null:@""];
//            //            model.driving = [NetworkHelper makeModelValueWithKey:@"driving" Model:dic Null:@""];
//            //            model.vehicle = [NetworkHelper makeModelValueWithKey:@"vehicle" Model:dic Null:@""];
//            //            model.operate = [NetworkHelper makeModelValueWithKey:@"operate" Model:dic Null:@""];
//            //
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //
//            //        case ApiEnumAudi://提交审核
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //        case ApiENumUploadPhoto://上传图片
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            uploadPhotoModel *model = [[uploadPhotoModel alloc] init];
//            //
//            //
//            //            model.paper_path = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"paper_path" Model:dic Null:@""]];
//            //
//            //            model.paper_id = [NetworkHelper makeModelValueWithKey:@"paper_id" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumCarouselList://轮播图
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            CarouselListModel *model = [[CarouselListModel alloc] init];
//            //            model.add_by = [NetworkHelper makeModelValueWithKey:@"add_by" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.banner_content = [NetworkHelper makeModelValueWithKey:@"banner_content" Model:dic Null:@""];
//            //            model.banner_image = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"banner_image" Model:dic Null:@""]];
//            //            model.banner_title = [NetworkHelper makeModelValueWithKey:@"banner_title" Model:dic Null:@""];
//            //            model.banner_type = [NetworkHelper makeModelValueWithKey:@"banner_type" Model:dic Null:@""];
//            //            model.bannner_id = [NetworkHelper makeModelValueWithKey:@"bannner_id" Model:dic Null:@""];
//            //            model.position = [NetworkHelper makeModelValueWithKey:@"position" Model:dic Null:@""];
//            //            model.sort = [NetworkHelper makeModelValueWithKey:@"sort" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.url = [NetworkHelper makeModelValueWithKey:@"url" Model:dic Null:@""];
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //        case ApiEnumCurrentStocks://获取当前库存
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            CurrentStocksModel *model = [[CurrentStocksModel alloc] init];
//            //            model.stock_id = [NetworkHelper makeModelValueWithKey:@"stock_id" Model:dic Null:@""];
//            //            model.current = [NetworkHelper makeModelValueWithKey:@"current" Model:dic Null:@""];
//            //            model.daily_fc = [NetworkHelper makeModelValueWithKey:@"daily_fc" Model:dic Null:@""];
//            //            model.alarm_ton = [NetworkHelper makeModelValueWithKey:@"alarm_ton" Model:dic Null:@""];
//            //            model.total = [NetworkHelper makeModelValueWithKey:@"total" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//        case ApiEnumSysmsgList://消息列表
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            SysmsgListModel *model = [[SysmsgListModel alloc] init];
//            model.msg_id = [NetworkHelper makeModelValueWithKey:@"msg_id" Model:dic Null:@""];
//            model.msg_title = [NetworkHelper makeModelValueWithKey:@"msg_title" Model:dic Null:@""];
//            model.from_user = [NetworkHelper makeModelValueWithKey:@"from_user" Model:dic Null:@""];
//            model.from_user_name = [NetworkHelper makeModelValueWithKey:@"from_user_name" Model:dic Null:@""];
//            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            model.msg_status = [NetworkHelper makeModelValueWithKey:@"msg_status" Model:dic Null:@""];
//            
//            return model;
//            
//        }
//            break;
//            
//        case ApiEnumDelMsg://删除消息
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//        }
//            break;
//            
//        case ApiEnumSysmsgInfo://消息详情
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            SysmsgInfoModel *model = [[SysmsgInfoModel alloc] init];
//            model.msg_id = [NetworkHelper makeModelValueWithKey:@"msg_id" Model:dic Null:@""];
//            model.msg_title = [NetworkHelper makeModelValueWithKey:@"msg_title" Model:dic Null:@""];
//            model.msg_content = [NetworkHelper makeModelValueWithKey:@"msg_content" Model:dic Null:@""];
//            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            
//            return model;
//            
//        }
//            break;
//            
//            //        case ApiEnumProductList://煤炭交易
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            ProductListModel *model = [[ProductListModel alloc] init];
//            //            model.product_id = [NetworkHelper makeModelValueWithKey:@"product_id" Model:dic Null:@""];
//            //            model.product_name = [NetworkHelper makeModelValueWithKey:@"product_name" Model:dic Null:@""];
//            //            model.cate_id = [NetworkHelper makeModelValueWithKey:@"cate_id" Model:dic Null:@""];
//            //            model.price = [NetworkHelper makeModelValueWithKey:@"price" Model:dic Null:@""];
//            //
//            //            model.calorific_value = [NetworkHelper makeModelValueWithKey:@"calorific_value" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.rate = [NetworkHelper makeModelValueWithKey:@"rate" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.process = [NetworkHelper makeModelValueWithKey:@"process" Model:dic Null:@""];
//            //            model.activities = [NetworkHelper makeModelValueWithKey:@"activities" Model:dic Null:@""];
//            //            return model;
//            //        }
//            //            break;
//            //
//            //
//            //        case ApiEnumShippingAddressDefault://默认收货
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            ShippingAddressDefaultModel *model = [[ShippingAddressDefaultModel alloc] init];
//            //            model.ra_id = [NetworkHelper makeModelValueWithKey:@"ra_id" Model:dic Null:@""];
//            //            model.contact = [NetworkHelper makeModelValueWithKey:@"contact" Model:dic Null:@""];
//            //            model.phone = [NetworkHelper makeModelValueWithKey:@"phone" Model:dic Null:@""];
//            //            model.address = [NetworkHelper makeModelValueWithKey:@"address" Model:dic Null:@""];
//            //            return model;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumProductInfo://煤炭详情
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            ProductInfoModel *model = [[ProductInfoModel alloc] init];
//            //            model.product_id = [NetworkHelper makeModelValueWithKey:@"product_id" Model:dic Null:@""];
//            //            model.product_name = [NetworkHelper makeModelValueWithKey:@"product_name" Model:dic Null:@""];
//            //            model.price = [NetworkHelper makeModelValueWithKey:@"price" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.calorific_value = [NetworkHelper makeModelValueWithKey:@"calorific_value" Model:dic Null:@""];
//            //            model.value = [NetworkHelper makeModelValueWithKey:@"value" Model:dic Null:@""];
//            //            model.f_freight = [NetworkHelper makeModelValueWithKey:@"f_freight" Model:dic Null:@""];
//            //            model.p_price = [NetworkHelper makeModelValueWithKey:@"p_price" Model:dic Null:@""];
//            //            model.descriptionString = [NetworkHelper makeModelValueWithKey:@"description" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.assay_sheet = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"assay_sheet" Model:dic Null:@""]];
//            //            model.rate = [NetworkHelper makeModelValueWithKey:@"rate" Model:dic Null:@""];
//            //            return model;
//            //        }
//            //            break;
//            //
//            //
//            //        case ApiEnumOrderAdd://提交订单
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumMyOrdersList://我的订单列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            MyOrdersListModel *model = [[MyOrdersListModel alloc] init];
//            //            model.tdo_id = [NetworkHelper makeModelValueWithKey:@"tdo_id" Model:dic Null:@""];
//            //            model.tdo_no = [NetworkHelper makeModelValueWithKey:@"tdo_no" Model:dic Null:@""];
//            //            model.product_id = [NetworkHelper makeModelValueWithKey:@"product_id" Model:dic Null:@""];
//            //            model.product_name = [NetworkHelper makeModelValueWithKey:@"product_name" Model:dic Null:@""];
//            //            model.price = [NetworkHelper makeModelValueWithKey:@"price" Model:dic Null:@""];
//            //            model.total = [NetworkHelper makeModelValueWithKey:@"total" Model:dic Null:@""];
//            //            model.cost = [NetworkHelper makeModelValueWithKey:@"cost" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.calorific_value = [NetworkHelper makeModelValueWithKey:@"calorific_value" Model:dic Null:@""];
//            //            model.transport = [NetworkHelper makeModelValueWithKey:@"transport" Model:dic Null:@""];
//            //            model.done = [NetworkHelper makeModelValueWithKey:@"done" Model:dic Null:@""];
//            //            model.process = [NetworkHelper makeModelValueWithKey:@"process" Model:dic Null:@""];
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumOrderInfo://订单详情
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            OrderInfoModel *model = [[OrderInfoModel alloc] init];
//            //            model.tdo_id = [NetworkHelper makeModelValueWithKey:@"tdo_id" Model:dic Null:@""];
//            //            model.tdo_no = [NetworkHelper makeModelValueWithKey:@"tdo_no" Model:dic Null:@""];
//            //            model.product_id = [NetworkHelper makeModelValueWithKey:@"product_id" Model:dic Null:@""];
//            //            model.product_name = [NetworkHelper makeModelValueWithKey:@"product_name" Model:dic Null:@""];
//            //            model.price = [NetworkHelper makeModelValueWithKey:@"price" Model:dic Null:@""];
//            //            model.total = [NetworkHelper makeModelValueWithKey:@"total" Model:dic Null:@""];
//            //            model.cost = [NetworkHelper makeModelValueWithKey:@"cost" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.calorific_value = [NetworkHelper makeModelValueWithKey:@"calorific_value" Model:dic Null:@""];
//            //            model.transport = [NetworkHelper makeModelValueWithKey:@"transport" Model:dic Null:@""];
//            //            model.done = [NetworkHelper makeModelValueWithKey:@"done" Model:dic Null:@""];
//            //            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            //
//            //            model.notes = [NetworkHelper makeModelValueWithKey:@"notes" Model:dic Null:@""];
//            //
//            //            model.value = [NetworkHelper makeModelValueWithKey:@"value" Model:dic Null:@""];
//            //
//            //
//            //            model.unload_time = [NetworkHelper makeModelValueWithKey:@"unload_time" Model:dic Null:@""];
//            //            model.unload_cost = [NetworkHelper makeModelValueWithKey:@"unload_cost" Model:dic Null:@""];
//            //
//            //            model.unload_contact = [NetworkHelper makeModelValueWithKey:@"unload_contact" Model:dic Null:@""];
//            //
//            //            model.unload_telephone = [NetworkHelper makeModelValueWithKey:@"unload_telephone" Model:dic Null:@""];
//            //            model.ra_address = [NetworkHelper makeModelValueWithKey:@"ra_address" Model:dic Null:@""];
//            //
//            //            model.paytype_name = [NetworkHelper makeModelValueWithKey:@"paytype_name" Model:dic Null:@""];
//            //
//            //            model.ra_contact = [NetworkHelper makeModelValueWithKey:@"ra_contact" Model:dic Null:@""];
//            //
//            //            model.ra_telephone = [NetworkHelper makeModelValueWithKey:@"ra_telephone" Model:dic Null:@""];
//            //            model.unload_info = [NetworkHelper makeModelValueWithKey:@"unload_info" Model:dic Null:@""];
//            //
//            //            model.audit_notes = [NetworkHelper makeModelValueWithKey:@"audit_notes" Model:dic Null:@""];
//            //
//            //            model.t_finish_status = [NetworkHelper makeModelValueWithKey:@"t_finish_status" Model:dic Null:@""];
//            //            model.t_ready_status = [NetworkHelper makeModelValueWithKey:@"t_ready_status" Model:dic Null:@""];
//            //
//            //
//            //            model.show_total = [NetworkHelper makeModelValueWithKey:@"show_total" Model:dic Null:@""];
//            //
//            //            model.show_price = [NetworkHelper makeModelValueWithKey:@"show_price" Model:dic Null:@""];
//            //            model.show_freight = [NetworkHelper makeModelValueWithKey:@"show_freight" Model:dic Null:@""];
//            //            model.total_price = [NetworkHelper makeModelValueWithKey:@"total_price" Model:dic Null:@""];
//            //
//            //            model.bystages = [NetworkHelper makeModelValueWithKey:@"bystages" Model:dic Null:@""];
//            //
//            //            model.assay_sheet = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"assay_sheet" Model:dic Null:@""]];
//            //            model.acceptance = [NetworkHelper makeModelValueWithKey:@"acceptance" Model:dic Null:@""];
//            //
//            ////            NSArray *array = [NetworkHelper makeModelValueWithKey:@"order_notes" Model:dic Null:@""];
//            ////            model.order_notes = [NSMutableArray array];
//            ////            for (NSDictionary *mydic in array) {
//            ////                [model.order_notes addObject:[NetworkHelper makeModelValueWithKey:@"notes" Model:mydic Null:@""]];
//            ////            }
//            //
//            //
//            //            return model;
//            //
//            //        }
//            //
//            //
//            //
//            //        case ApiEnumLogisticsList://物流列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            LogisticsListModel *model = [[LogisticsListModel alloc] init];
//            //            model.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            //            model.trans_no = [NetworkHelper makeModelValueWithKey:@"trans_no" Model:dic Null:@""];
//            //            model.grabbed_time = [NetworkHelper makeModelValueWithKey:@"grabbed_time" Model:dic Null:@""];
//            //            model.done_time = [NetworkHelper makeModelValueWithKey:@"done_time" Model:dic Null:@""];
//            //            model.trans_status = [NetworkHelper makeModelValueWithKey:@"trans_status" Model:dic Null:@""];
//            //            model.truck_id = [NetworkHelper makeModelValueWithKey:@"truck_id" Model:dic Null:@""];
//            //            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            //            model.is_img = [NetworkHelper makeModelValueWithKey:@"is_img" Model:dic Null:@""];
//            //            model.is_evaluate = [NetworkHelper makeModelValueWithKey:@"is_evaluate" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumOrderDoneList://一键买煤
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            OrderDoneListModel *model = [[OrderDoneListModel alloc] init];
//            //            model.user_id = [NetworkHelper makeModelValueWithKey:@"user_id" Model:dic Null:@""];
//            //            model.unload_time = [NetworkHelper makeModelValueWithKey:@"unload_time" Model:dic Null:@""];
//            //            model.unload_telephone = [NetworkHelper makeModelValueWithKey:@"unload_telephone" Model:dic Null:@""];
//            //            model.unload_cost = [NetworkHelper makeModelValueWithKey:@"unload_cost" Model:dic Null:@""];
//            //            model.unload_contact = [NetworkHelper makeModelValueWithKey:@"unload_contact" Model:dic Null:@""];
//            //            model.unit = [NetworkHelper makeModelValueWithKey:@"unit" Model:dic Null:@""];
//            //            model.total_price = [NetworkHelper makeModelValueWithKey:@"total_price" Model:dic Null:@""];
//            //
//            //            model.ra_contact = [NetworkHelper makeModelValueWithKey:@"ra_contact" Model:dic Null:@""];
//            //            model.ra_id = [NetworkHelper makeModelValueWithKey:@"ra_id" Model:dic Null:@""];
//            //            model.ra_telephone = [NetworkHelper makeModelValueWithKey:@"ra_telephone" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.tdo_id = [NetworkHelper makeModelValueWithKey:@"tdo_id" Model:dic Null:@""];
//            //            model.tdo_no = [NetworkHelper makeModelValueWithKey:@"tdo_no" Model:dic Null:@""];
//            //            model.total = [NetworkHelper makeModelValueWithKey:@"total" Model:dic Null:@""];
//            //
//            //
//            //            model.freight_paytype = [NetworkHelper makeModelValueWithKey:@"freight_paytype" Model:dic Null:@""];
//            //            model.notes = [NetworkHelper makeModelValueWithKey:@"notes" Model:dic Null:@""];
//            //            model.price = [NetworkHelper makeModelValueWithKey:@"price" Model:dic Null:@""];
//            //            model.payment_id = [NetworkHelper makeModelValueWithKey:@"payment_id" Model:dic Null:@""];
//            //            model.product_id = [NetworkHelper makeModelValueWithKey:@"product_id" Model:dic Null:@""];
//            //            model.product_name = [NetworkHelper makeModelValueWithKey:@"product_name" Model:dic Null:@""];
//            //            model.ra_address = [NetworkHelper makeModelValueWithKey:@"ra_address" Model:dic Null:@""];
//            //
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.audit_by = [NetworkHelper makeModelValueWithKey:@"audit_by" Model:dic Null:@""];
//            //            model.ra_telephone = [NetworkHelper makeModelValueWithKey:@"ra_telephone" Model:dic Null:@""];
//            //            model.audit_notes = [NetworkHelper makeModelValueWithKey:@"audit_notes" Model:dic Null:@""];
//            //            model.calorific_value = [NetworkHelper makeModelValueWithKey:@"calorific_value" Model:dic Null:@""];
//            //            model.cost = [NetworkHelper makeModelValueWithKey:@"cost" Model:dic Null:@""];
//            //            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            //            model.process = [NetworkHelper makeModelValueWithKey:@"process" Model:dic Null:@""];
//            //            model.bystages = [NetworkHelper makeModelValueWithKey:@"bystages" Model:dic Null:@""];
//            //            model.assay_sheet = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"assay_sheet" Model:dic Null:@""]];
//            //            model.descriptionString = [NetworkHelper makeModelValueWithKey:@"descriptionString" Model:dic Null:@""];
//            //            model.acceptance = [NetworkHelper makeModelValueWithKey:@"acceptance" Model:dic Null:@""];
//            //            return model;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumClientManager://我的订单列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            ClientManagerModel *model = [[ClientManagerModel alloc] init];
//            //            model.avatar = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"avatar" Model:dic Null:@""]];
//            //            model.ceil_phone = [NetworkHelper makeModelValueWithKey:@"ceil_phone" Model:dic Null:@""];
//            //            model.employee_id = [NetworkHelper makeModelValueWithKey:@"employee_id" Model:dic Null:@""];
//            //            model.employee_name = [NetworkHelper makeModelValueWithKey:@"employee_name" Model:dic Null:@""];
//            //            model.precinct = [NetworkHelper makeModelValueWithKey:@"precinct" Model:dic Null:@""];
//            //            model.role_name = [NetworkHelper makeModelValueWithKey:@"role_name" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumWaybillList://运单列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            WaybillListModel *model = [[WaybillListModel alloc] init];
//            //            model.shorter_form_load = [NetworkHelper makeModelValueWithKey:@"shorter_form_load" Model:dic Null:@""];
//            //            model.shorter_form_unload = [NetworkHelper makeModelValueWithKey:@"shorter_form_unload" Model:dic Null:@""];
//            //            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            //            model.total = [NetworkHelper makeModelValueWithKey:@"total" Model:dic Null:@""];
//            //            model.contact = [NetworkHelper makeModelValueWithKey:@"contact" Model:dic Null:@""];
//            //            model.telephone = [NetworkHelper makeModelValueWithKey:@"telephone" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.tso_id = [NetworkHelper makeModelValueWithKey:@"tso_id" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//        case ApiEnumGrabTransport ://抢单
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            grabTransportModel *model = [[grabTransportModel alloc] init];
//            model.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            model.grabbed_time = [NetworkHelper makeModelValueWithKey:@"grabbed_time" Model:dic Null:@""];
//            model.contact = [NetworkHelper makeModelValueWithKey:@"contact" Model:dic Null:@""];
//            model.telephone = [NetworkHelper makeModelValueWithKey:@"telephone" Model:dic Null:@""];
//            return model;
//            
//        }
//            break;
//            
//            
//            //        case ApiEnumHistoryList://运单历史列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            HistoryListModel *model = [[HistoryListModel alloc] init];
//            //            model.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            //            model.shorter_form_load = [NetworkHelper makeModelValueWithKey:@"shorter_form_load" Model:dic Null:@""];
//            //            model.shorter_form_unload = [NetworkHelper makeModelValueWithKey:@"shorter_form_unload" Model:dic Null:@""];
//            //            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            //            model.trans_status = [NetworkHelper makeModelValueWithKey:@"trans_status" Model:dic Null:@""];
//            //            model.arrive_time = [NetworkHelper makeModelValueWithKey:@"arrive_time" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //
//            //
//            //        case ApiEnumFeedback://意见反馈
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumShippingAddressList://收货地址列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            ShippingAddressListModel *model = [[ShippingAddressListModel alloc] init];
//            //            model.add_by = [NetworkHelper makeModelValueWithKey:@"add_by" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.address = [NetworkHelper makeModelValueWithKey:@"address" Model:dic Null:@""];
//            //            model.change_by = [NetworkHelper makeModelValueWithKey:@"change_by" Model:dic Null:@""];
//            //            model.change_time = [NetworkHelper makeModelValueWithKey:@"change_time" Model:dic Null:@""];
//            //            model.city = [NetworkHelper makeModelValueWithKey:@"city" Model:dic Null:@""];
//            //            model.city_id = [NetworkHelper makeModelValueWithKey:@"city_id" Model:dic Null:@""];
//            //            model.city_name = [NetworkHelper makeModelValueWithKey:@"city_name" Model:dic Null:@""];
//            //            model.contact = [NetworkHelper makeModelValueWithKey:@"contact" Model:dic Null:@""];
//            //            model.country = [NetworkHelper makeModelValueWithKey:@"country" Model:dic Null:@""];
//            //            model.county = [NetworkHelper makeModelValueWithKey:@"county" Model:dic Null:@""];
//            //            model.county_id = [NetworkHelper makeModelValueWithKey:@"county_id" Model:dic Null:@""];
//            //            model.county_name = [NetworkHelper makeModelValueWithKey:@"county_name" Model:dic Null:@""];
//            //            model.phone = [NetworkHelper makeModelValueWithKey:@"phone" Model:dic Null:@""];
//            //            model.province = [NetworkHelper makeModelValueWithKey:@"province" Model:dic Null:@""];
//            //            model.province_id = [NetworkHelper makeModelValueWithKey:@"province_id" Model:dic Null:@""];
//            //            model.province_name = [NetworkHelper makeModelValueWithKey:@"province_name" Model:dic Null:@""];
//            //            model.ra_id = [NetworkHelper makeModelValueWithKey:@"ra_id" Model:dic Null:@""];
//            //            model.shorname = [NetworkHelper makeModelValueWithKey:@"shorname" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.user_id = [NetworkHelper makeModelValueWithKey:@"user_id" Model:dic Null:@""];
//            //            model.zipcode = [NetworkHelper makeModelValueWithKey:@"zipcode" Model:dic Null:@""];
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumShippingAddressDel://删除收货地址
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumDefaultAddress://设置默认收货地址
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumShippingAddressInfo://收货地址详情
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            ShippingAddressListModel *model = [[ShippingAddressListModel alloc] init];
//            //            model.add_by = [NetworkHelper makeModelValueWithKey:@"add_by" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.address = [NetworkHelper makeModelValueWithKey:@"address" Model:dic Null:@""];
//            //            model.change_by = [NetworkHelper makeModelValueWithKey:@"change_by" Model:dic Null:@""];
//            //            model.change_time = [NetworkHelper makeModelValueWithKey:@"change_time" Model:dic Null:@""];
//            //            model.city = [NetworkHelper makeModelValueWithKey:@"city" Model:dic Null:@""];
//            //            model.city_id = [NetworkHelper makeModelValueWithKey:@"city_id" Model:dic Null:@""];
//            //            model.city_name = [NetworkHelper makeModelValueWithKey:@"city_name" Model:dic Null:@""];
//            //            model.contact = [NetworkHelper makeModelValueWithKey:@"contact" Model:dic Null:@""];
//            //            model.country = [NetworkHelper makeModelValueWithKey:@"country" Model:dic Null:@""];
//            //            model.county = [NetworkHelper makeModelValueWithKey:@"county" Model:dic Null:@""];
//            //            model.county_id = [NetworkHelper makeModelValueWithKey:@"county_id" Model:dic Null:@""];
//            //            model.county_name = [NetworkHelper makeModelValueWithKey:@"county_name" Model:dic Null:@""];
//            //            model.phone = [NetworkHelper makeModelValueWithKey:@"phone" Model:dic Null:@""];
//            //            model.province = [NetworkHelper makeModelValueWithKey:@"province" Model:dic Null:@""];
//            //            model.province_id = [NetworkHelper makeModelValueWithKey:@"province_id" Model:dic Null:@""];
//            //            model.province_name = [NetworkHelper makeModelValueWithKey:@"province_name" Model:dic Null:@""];
//            //            model.ra_id = [NetworkHelper makeModelValueWithKey:@"ra_id" Model:dic Null:@""];
//            //            model.shorname = [NetworkHelper makeModelValueWithKey:@"shorname" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.user_id = [NetworkHelper makeModelValueWithKey:@"user_id" Model:dic Null:@""];
//            //            model.zipcode = [NetworkHelper makeModelValueWithKey:@"zipcode" Model:dic Null:@""];
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //        case ApiEnumShippingAddressAdd://添加收货地址
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //        case ApiEnumShippingAddressModify://修改收货地址
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //        case ApiEnumConsumeConfAdd://提交库存配置
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //        case ApiEnumConsumeHistoryList://消耗历史
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            ConsumeHistoryListModel *model = [[ConsumeHistoryListModel alloc] init];
//            //            model.stock_in = [NetworkHelper makeModelValueWithKey:@"stock_in" Model:dic Null:@""];
//            //            model.day = [NetworkHelper makeModelValueWithKey:@"day" Model:dic Null:@""];
//            //            model.daily_fc = [NetworkHelper makeModelValueWithKey:@"daily_fc" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //        case ApiEnumConsumeHistoryListModify://修改消耗历史
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//        case ApiEnumGetStartAd://广告页面
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            getStartAdModel *model = [[getStartAdModel alloc] init];
//            model.conf_value = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"conf_value" Model:dic Null:@""]];
//            model.url = [NetworkHelper makeModelValueWithKey:@"url" Model:dic Null:@""];
//            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            return model;
//            
//        }
//            break;
//            //        case ApiEnumRemoveOrders://删除订单
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumOrderTree://订单树
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            OrderTreeModel *model = [[OrderTreeModel alloc] init];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.name = [NetworkHelper makeModelValueWithKey:@"name" Model:dic Null:@""];
//            //            model.t_status = [NetworkHelper makeModelValueWithKey:@"t_status" Model:dic Null:@""];
//            //            model.content = [NetworkHelper makeModelValueWithKey:@"content" Model:dic Null:@""];
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumOrderImages://查看单据
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            OrderImagesModel *model = [[OrderImagesModel alloc] init];
//            //            model.realname = [NetworkHelper makeModelValueWithKey:@"realname" Model:dic Null:@""];
//            //            model.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            //            model.send_img = [NSString stringWithFormat:@"%@%@", url,[NetworkHelper makeModelValueWithKey:@"send_img" Model:dic Null:@""]];
//            //            model.weigh_img = [NSString stringWithFormat:@"%@%@", url,[NetworkHelper makeModelValueWithKey:@"weigh_img" Model:dic Null:@""]];
//            //            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            
//            
//        case ApiEnumCrumbleInfo://记录用户崩溃信息
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//        }
//            break;
//            
//            //        case ApiEnumEvaluateAdd://提交评价单
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumOrderDel://取消订单
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumTrucksPhotol://上传票据
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            TrucksPhotolModel *model = [[TrucksPhotolModel alloc] init];
//            //
//            //            model.photo_path = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"photo_path" Model:dic Null:@""]];
//            //
//            //            model.photo_id = [NetworkHelper makeModelValueWithKey:@"photo_id" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //        case ApiEnumCheckTrucksPhoto://获得票据
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            CheckTrucksPhotoModel *model = [[CheckTrucksPhotoModel alloc] init];
//            //
//            //            NSArray *paper = [NetworkHelper makeModelValueWithKey:@"paper" Model:dic Null:@""];
//            //            model.paper = [NSMutableArray array];
//            //            for (NSDictionary *dic in paper) {
//            //                paperModel *papermodel = [[paperModel alloc] init];
//            //                papermodel.paper_id = [NetworkHelper makeModelValueWithKey:@"paper_id" Model:dic Null:@""];
//            //                papermodel.paper_path = [NSString stringWithFormat:@"%@%@", url,[NetworkHelper makeModelValueWithKey:@"paper_path" Model:dic Null:@""]];
//            //                papermodel.ptype_id = [NetworkHelper makeModelValueWithKey:@"ptype_id" Model:dic Null:@""];
//            //                [model.paper addObject:papermodel];
//            //            }
//            //
//            //
//            //
//            //            NSArray *photo = [NetworkHelper makeModelValueWithKey:@"photo" Model:dic Null:@""];
//            //            model.photo = [NSMutableArray array];
//            //            for (NSDictionary *dic in photo) {
//            //                photoModel *photomodel = [[photoModel alloc] init];
//            //                photomodel.photo_id = [NetworkHelper makeModelValueWithKey:@"photo_id" Model:dic Null:@""];
//            //                photomodel.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            //                photomodel.pt_id = [NetworkHelper makeModelValueWithKey:@"pt_id" Model:dic Null:@""];
//            //                photomodel.photo_path = [NSString stringWithFormat:@"%@%@", url,[NetworkHelper makeModelValueWithKey:@"photo_path" Model:dic Null:@""]];
//            //                [model.photo addObject:photomodel];
//            //            }
//            //
//            //
//            //            model.td_status = [NetworkHelper makeModelValueWithKey:@"td_status" Model:dic Null:@""];
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //
//            //        case ApiEnumTrucksLocation://获取司机坐标
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            TrucksLocationModel *model = [[TrucksLocationModel alloc] init];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.address = [NetworkHelper makeModelValueWithKey:@"address" Model:dic Null:@""];
//            //            model.latitude = [NetworkHelper makeModelValueWithKey:@"latitude" Model:dic Null:@""];
//            //            model.longitude = [NetworkHelper makeModelValueWithKey:@"longitude" Model:dic Null:@""];
//            //            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            //            model.realname = [NetworkHelper makeModelValueWithKey:@"realname" Model:dic Null:@""];
//            //            return model;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumDelTrucksPhoto://删除司机上传图片
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //
//            //            return dic;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumSendBaiduPushAccount:///百度推送
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumAddLocation://司机上传定位
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumGetSubCities://获取省市区
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            subacityModel *model = [[subacityModel alloc] init];
//            //            model.city_id = [NetworkHelper makeModelValueWithKey:@"city_id" Model:dic Null:@""];
//            //            model.city_name = [NetworkHelper makeModelValueWithKey:@"city_name" Model:dic Null:@""];
//            //            model.displayorder = [NetworkHelper makeModelValueWithKey:@"displayorder" Model:dic Null:@""];
//            //            model.level = [NetworkHelper makeModelValueWithKey:@"level" Model:dic Null:@""];
//            //            model.upid = [NetworkHelper makeModelValueWithKey:@"upid" Model:dic Null:@""];
//            //            model.usetype = [NetworkHelper makeModelValueWithKey:@"usetype" Model:dic Null:@""];
//            //            return model;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumGetProductCategory://获取煤炭信息筛选的煤种分类
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            CoalKindModel *model = [[CoalKindModel alloc] init];
//            //            model.cate_id = [NetworkHelper makeModelValueWithKey:@"cate_id" Model:dic Null:@""];
//            //            model.cate_name = [NetworkHelper makeModelValueWithKey:@"cate_name" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumGetProductQnet://获取发热量筛选的分类
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            CoalHotModel *model = [[CoalHotModel alloc] init];
//            //            model.Qnet = [NetworkHelper makeModelValueWithKey:@"Qnet" Model:dic Null:@""];
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumGetWaybillInfo://历史运单详情
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            TransInfoModel *model = [[TransInfoModel alloc] init];
//            //
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.arrive_time = [NetworkHelper makeModelValueWithKey:@"arrive_time" Model:dic Null:@""];
//            //            model.cate_name = [NetworkHelper makeModelValueWithKey:@"cate_name" Model:dic Null:@""];
//            //            model.company_id = [NetworkHelper makeModelValueWithKey:@"company_id" Model:dic Null:@""];
//            //            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            //            model.latitude = [NetworkHelper makeModelValueWithKey:@"latitude" Model:dic Null:@""];
//            //            model.load_address = [NetworkHelper makeModelValueWithKey:@"load_address" Model:dic Null:@""];
//            //            model.load_time = [NetworkHelper makeModelValueWithKey:@"load_time" Model:dic Null:@""];
//            //
//            //
//            //
//            //            model.load_info = [NetworkHelper makeModelValueWithKey:@"load_info" Model:dic Null:@""];
//            //            model.longitude = [NetworkHelper makeModelValueWithKey:@"longitude" Model:dic Null:@""];
//            //            model.manage_phone = [NetworkHelper makeModelValueWithKey:@"manage_phone" Model:dic Null:@""];
//            //            model.notes = [NetworkHelper makeModelValueWithKey:@"notes" Model:dic Null:@""];
//            //            model.ra_address = [NetworkHelper makeModelValueWithKey:@"ra_address" Model:dic Null:@""];
//            //            model.ra_contact = [NetworkHelper makeModelValueWithKey:@"ra_contact" Model:dic Null:@""];
//            //            model.ra_telephone = [NetworkHelper makeModelValueWithKey:@"ra_telephone" Model:dic Null:@""];
//            //            model.router = [NetworkHelper makeModelValueWithKey:@"router" Model:dic Null:@""];
//            //            model.shorter_form_load = [NetworkHelper makeModelValueWithKey:@"shorter_form_load" Model:dic Null:@""];
//            //
//            //
//            //
//            //
//            //            model.shorter_form_unload = [NetworkHelper makeModelValueWithKey:@"shorter_form_unload" Model:dic Null:@""];
//            //            model.td_status = [NetworkHelper makeModelValueWithKey:@"td_status" Model:dic Null:@""];
//            //            model.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            //            model.trans_no = [NetworkHelper makeModelValueWithKey:@"trans_no" Model:dic Null:@""];
//            //            model.trans_status = [NetworkHelper makeModelValueWithKey:@"trans_status" Model:dic Null:@""];
//            //            model.upload_img = [NetworkHelper makeModelValueWithKey:@"upload_img" Model:dic Null:@""];
//            //            model.unload_time = [NetworkHelper makeModelValueWithKey:@"unload_time" Model:dic Null:@""];
//            //            model.unload_info = [NetworkHelper makeModelValueWithKey:@"unload_info" Model:dic Null:@""];
//            //
//            //
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumGetBindBankCard://绑定银行卡
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            CoalHotModel *model = [[CoalHotModel alloc] init];
//            //            model.Qnet = [NetworkHelper makeModelValueWithKey:@"Qnet" Model:dic Null:@""];
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //        case ApiEnumGetDelBankCardt://删除银行卡绑定
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            CoalHotModel *model = [[CoalHotModel alloc] init];
//            //            model.Qnet = [NetworkHelper makeModelValueWithKey:@"Qnet" Model:dic Null:@""];
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //
//            //        case ApiEnumGetBankCardList://银行卡列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            BankListModel *model = [[BankListModel alloc] init];
//            //            model.user_id = [NetworkHelper makeModelValueWithKey:@"user_id" Model:dic Null:@""];
//            //            model.bc_id = [NetworkHelper makeModelValueWithKey:@"bc_id" Model:dic Null:@""];
//            //            model.bc_no = [NetworkHelper makeModelValueWithKey:@"bc_no" Model:dic Null:@""];
//            //            model.card_owner = [NetworkHelper makeModelValueWithKey:@"card_owner" Model:dic Null:@""];
//            //            model.bc_bank = [NetworkHelper makeModelValueWithKey:@"bc_bank" Model:dic Null:@""];
//            //            model.bc_bank_of_deposit = [NetworkHelper makeModelValueWithKey:@"bc_bank_of_deposit" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumTransportList: //买家查看运单列表(下线付款)
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            transportListModel *model = [[transportListModel alloc] init];
//            //            model.trans_no = [NetworkHelper makeModelValueWithKey:@"trans_no" Model:dic Null:@""];
//            //            model.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            //            model.receive_weight = [NetworkHelper makeModelValueWithKey:@"receive_weight" Model:dic Null:@""];
//            //            model.realname = [NetworkHelper makeModelValueWithKey:@"realname" Model:dic Null:@""];
//            //            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            //            model.current_price = [NetworkHelper makeModelValueWithKey:@"current_price" Model:dic Null:@""];
//            //            model.current_freight = [NetworkHelper makeModelValueWithKey:@"current_freight" Model:dic Null:@""];
//            //            model.current_total_price = [NetworkHelper makeModelValueWithKey:@"current_total_price" Model:dic Null:@""];
//            //
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //        case ApiEnumTransportHistoryList://买家查看运单历史(下线付款)
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            transportHistoryListModel *model = [[transportHistoryListModel alloc] init];
//            //            model.trans_no = [NetworkHelper makeModelValueWithKey:@"trans_no" Model:dic Null:@""];
//            //            model.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            //            model.receive_weight = [NetworkHelper makeModelValueWithKey:@"receive_weight" Model:dic Null:@""];
//            //            model.realname = [NetworkHelper makeModelValueWithKey:@"realname" Model:dic Null:@""];
//            //            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            //            model.current_price = [NetworkHelper makeModelValueWithKey:@"current_price" Model:dic Null:@""];
//            //            model.current_freight = [NetworkHelper makeModelValueWithKey:@"current_freight" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //            model.current_total_price = [NetworkHelper makeModelValueWithKey:@"current_total_price" Model:dic Null:@""];
//            //            return model;
//            //
//            //        }
//            //            break;
//            //
//            //
//            //        case ApiEnumPushPurchase://司机推送品鉴部
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumCommitReceipt://买家确定提交票据
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            return dic;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumCheckReceipt://买家查看上传票据
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            checkReceiptMopdel *model = [[checkReceiptMopdel alloc] init];
//            //            model.photo_id = [NetworkHelper makeModelValueWithKey:@"photo_id" Model:dic Null:@""];
//            //            model.pt_id = [NetworkHelper makeModelValueWithKey:@"pt_id" Model:dic Null:@""];
//            //            model.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            //            model.photo_path = [NSString stringWithFormat:@"%@%@", url,[NetworkHelper makeModelValueWithKey:@"photo_path" Model:dic Null:@""]];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.add_by = [NetworkHelper makeModelValueWithKey:@"add_by" Model:dic Null:@""];
//            //
//            //
//            //            return model;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumAdAlert://广告通知
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            AdAlertModel *model = [[AdAlertModel alloc] init];
//            //            model.bannner_id = [NetworkHelper makeModelValueWithKey:@"bannner_id" Model:dic Null:@""];
//            //            model.banner_title = [NetworkHelper makeModelValueWithKey:@"banner_title" Model:dic Null:@""];
//            //            model.banner_content = [NetworkHelper makeModelValueWithKey:@"banner_content" Model:dic Null:@""];
//            //            model.banner_image = [NSString stringWithFormat:@"%@%@", url,[NetworkHelper makeModelValueWithKey:@"banner_image" Model:dic Null:@""]];
//            //            model.url = [NetworkHelper makeModelValueWithKey:@"url" Model:dic Null:@""];
//            //            model.status = [NetworkHelper makeModelValueWithKey:@"status" Model:dic Null:@""];
//            //
//            //
//            //            return model;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumAddressAddShow://获取省市区
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            areaModel *model = [[areaModel alloc] init];
//            //            model.address = [NetworkHelper makeModelValueWithKey:@"address" Model:dic Null:@""];
//            //            model.city_id = [NetworkHelper makeModelValueWithKey:@"city_id" Model:dic Null:@""];
//            //            model.city_name = [NetworkHelper makeModelValueWithKey:@"city_name" Model:dic Null:@""];
//            //            model.county_id = [NetworkHelper makeModelValueWithKey:@"county_id" Model:dic Null:@""];
//            //            model.county_name = [NetworkHelper makeModelValueWithKey:@"county_name" Model:dic Null:@""];
//            //            model.province_id = [NetworkHelper makeModelValueWithKey:@"province_id" Model:dic Null:@""];
//            //            model.province_name = [NetworkHelper makeModelValueWithKey:@"province_name" Model:dic Null:@""];
//            //            return model;
//            //        }
//            //            break;
//            
//        case ApiEnumVersion://获取版本信息
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            AppStoreVersionModel *model = [[AppStoreVersionModel alloc] init];
//            model.app_url = [NetworkHelper makeModelValueWithKey:@"app_url" Model:dic Null:@""];
//            model.update_type = [NetworkHelper makeModelValueWithKey:@"update_type" Model:dic Null:@""];
//            model.ver_description = [NetworkHelper makeModelValueWithKey:@"ver_description" Model:dic Null:@""];
//            model.web_url = [NetworkHelper makeModelValueWithKey:@"web_url" Model:dic Null:@""];
//            model.ver_no = [NetworkHelper makeModelValueWithKey:@"ver_no" Model:dic Null:@""];
//            return model;
//        }
//            break;
//            
//            //        case ApiEnumGetTradingVolume://获取交易量
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            GetTradingVolumeModel *model = [[GetTradingVolumeModel alloc] init];
//            //            model.volume = [NetworkHelper makeModelValueWithKey:@"volume" Model:dic Null:@""];
//            //            return model;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumGetDataList://单据列表
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            GetDataListModel *model = [[GetDataListModel alloc] init];
//            //            model.idString = [NetworkHelper makeModelValueWithKey:@"id" Model:dic Null:@""];
//            //            model.user_id = [NetworkHelper makeModelValueWithKey:@"user_id" Model:dic Null:@""];
//            //            model.u_status = [NetworkHelper makeModelValueWithKey:@"u_status" Model:dic Null:@""];
//            //            model.app_name = [NetworkHelper makeModelValueWithKey:@"app_name" Model:dic Null:@""];
//            //            model.order_id = [NetworkHelper makeModelValueWithKey:@"order_id" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.img_1 = [NetworkHelper makeModelValueWithKey:@"img_1" Model:dic Null:@""];
//            //            model.img_2 = [NetworkHelper makeModelValueWithKey:@"img_2" Model:dic Null:@""];
//            //            model.img_3 = [NetworkHelper makeModelValueWithKey:@"img_3" Model:dic Null:@""];
//            //            model.img_4 = [NetworkHelper makeModelValueWithKey:@"img_4" Model:dic Null:@""];
//            //            model.img_5 = [NetworkHelper makeModelValueWithKey:@"img_5" Model:dic Null:@""];
//            //
//            //            model.realname = [NetworkHelper makeModelValueWithKey:@"realname" Model:dic Null:@""];
//            //            return model;
//            //        }
//            //            break;
//            //
//            //
//            //        case ApiEnumGetDataInfo://单据详情
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            GetDataInfoModel *model = [[GetDataInfoModel alloc] init];
//            //            model.idString = [NetworkHelper makeModelValueWithKey:@"id" Model:dic Null:@""];
//            //            model.user_id = [NetworkHelper makeModelValueWithKey:@"user_id" Model:dic Null:@""];
//            //            model.u_status = [NetworkHelper makeModelValueWithKey:@"u_status" Model:dic Null:@""];
//            //            model.app_name = [NetworkHelper makeModelValueWithKey:@"app_name" Model:dic Null:@""];
//            //            model.order_id = [NetworkHelper makeModelValueWithKey:@"order_id" Model:dic Null:@""];
//            //            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            //            model.img_1 = [NetworkHelper makeModelValueWithKey:@"img_1" Model:dic Null:@""];
//            //            model.img_2 = [NetworkHelper makeModelValueWithKey:@"img_2" Model:dic Null:@""];
//            //            model.img_3 = [NetworkHelper makeModelValueWithKey:@"img_3" Model:dic Null:@""];
//            //            model.img_4 = [NetworkHelper makeModelValueWithKey:@"img_4" Model:dic Null:@""];
//            //            model.img_5 = [NetworkHelper makeModelValueWithKey:@"img_5" Model:dic Null:@""];
//            //            return model;
//            //        }
//            //            break;
//            //
//            //        case ApiEnumUploadImg://提交单据图片
//            //        {
//            //            NSDictionary *dic = (NSDictionary *)modelObj;
//            //            UploadImgModel *model = [[UploadImgModel alloc] init];
//            //            model.url = [NSString stringWithFormat:@"%@%@",url,[NetworkHelper makeModelValueWithKey:@"url" Model:dic Null:@""]];
//            //            return model;
//            //        }
//            //            break;
//            
//            
//        case ApiEnumPublishOrder://发布货源
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//        }
//            break;
//            
//        case ApiEnumGetUserInfo://个人信息
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            getUserInfoModel *model = [[getUserInfoModel alloc] init];
//            model.realname = [NetworkHelper makeModelValueWithKey:@"realname" Model:dic Null:@""];
//            model.avatar = [NSString stringWithFormat:@"%@%@", url,[NetworkHelper makeModelValueWithKey:@"avatar" Model:dic Null:@""]];
//            
//            model.ceil_phone = [NetworkHelper makeModelValueWithKey:@"ceil_phone" Model:dic Null:@""];
//            model.user_type = [NetworkHelper makeModelValueWithKey:@"user_type" Model:dic Null:@""];
//            
//            model.total_freight = [NetworkHelper makeModelValueWithKey:@"total_freight" Model:dic Null:@""];
//            
//            model.trans_num = [NetworkHelper makeModelValueWithKey:@"trans_num" Model:dic Null:@""];
//            model.u_status = [NetworkHelper makeModelValueWithKey:@"u_status" Model:dic Null:@""];
//            
//            model.addr_end = [NetworkHelper makeModelValueWithKey:@"addr_end" Model:dic Null:@""];
//            model.addr_start = [NetworkHelper makeModelValueWithKey:@"addr_start" Model:dic Null:@""];
//            model.money = [NetworkHelper makeModelValueWithKey:@"money" Model:dic Null:@""];
//            model.company_id = [NetworkHelper makeModelValueWithKey:@"company_id" Model:dic Null:@""];
//            
//            
//            return model;
//        }
//            break;
//            
//        case     ApiEnumUploadAvatar ://上传头像
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            uploadAvatarModel *model = [[uploadAvatarModel alloc] init];
//            
//            model.avatar = [NSString stringWithFormat:@"%@%@", url,[NetworkHelper makeModelValueWithKey:@"avatar" Model:dic Null:@""]];
//            
//            return model;
//        }
//            break;
//            
//            
//        case ApiEnumGetOrdersList://货主端运单列表
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            getOrdersListModel *model = [[getOrdersListModel alloc] init];
//            model.tso_id = [NetworkHelper makeModelValueWithKey:@"tso_id" Model:dic Null:@""];
//            model.tso_no = [NetworkHelper makeModelValueWithKey:@"tso_no" Model:dic Null:@""];
//            model.from = [NetworkHelper makeModelValueWithKey:@"from" Model:dic Null:@""];
//            model.to = [NetworkHelper makeModelValueWithKey:@"to" Model:dic Null:@""];
//            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            model.trans_num = [NetworkHelper makeModelValueWithKey:@"trans_num" Model:dic Null:@""];
//            
//            model.load_cost = [NetworkHelper makeModelValueWithKey:@"load_cost" Model:dic Null:@""];
//            model.unload_cost = [NetworkHelper makeModelValueWithKey:@"unload_cost" Model:dic Null:@""];
//            
//            model.coal_type = [NetworkHelper makeModelValueWithKey:@"coal_type" Model:dic Null:@""];
//            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            model.to_status = [NetworkHelper makeModelValueWithKey:@"to_status" Model:dic Null:@""];
//            return model;
//        }
//            break;
//            
//            
//        case ApiEnumGetOrderInfo://货主端运单详情
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            getOrderInfo *model = [[getOrderInfo alloc] init];
//            model.tso_no = [NetworkHelper makeModelValueWithKey:@"tso_no" Model:dic Null:@""];
//            model.from = [NetworkHelper makeModelValueWithKey:@"from" Model:dic Null:@""];
//            model.from_full = [NetworkHelper makeModelValueWithKey:@"from_full" Model:dic Null:@""];
//            model.to = [NetworkHelper makeModelValueWithKey:@"to" Model:dic Null:@""];
//            model.to_full = [NetworkHelper makeModelValueWithKey:@"to_full" Model:dic Null:@""];
//            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            model.freight_paytype = [NetworkHelper makeModelValueWithKey:@"freight_paytype" Model:dic Null:@""];
//            
//            model.load_time = [NetworkHelper makeModelValueWithKey:@"load_time" Model:dic Null:@""];
//            model.unload_time = [NetworkHelper makeModelValueWithKey:@"unload_time" Model:dic Null:@""];
//            
//            model.load_cost = [NetworkHelper makeModelValueWithKey:@"load_cost" Model:dic Null:@""];
//            model.unload_cost = [NetworkHelper makeModelValueWithKey:@"unload_cost" Model:dic Null:@""];
//            
//            model.coal_type = [NetworkHelper makeModelValueWithKey:@"coal_type" Model:dic Null:@""];
//            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            model.msg_cost = [NetworkHelper makeModelValueWithKey:@"msg_cost" Model:dic Null:@""];
//            model.notes = [NetworkHelper makeModelValueWithKey:@"notes" Model:dic Null:@""];
//            model.pick_address = [NetworkHelper makeModelValueWithKey:@"pick_address" Model:dic Null:@""];
//            model.total = [NetworkHelper makeModelValueWithKey:@"total" Model:dic Null:@""];
//            model.load_address = [NetworkHelper makeModelValueWithKey:@"load_address" Model:dic Null:@""];
//            model.unload_address = [NetworkHelper makeModelValueWithKey:@"unload_address" Model:dic Null:@""];
//            model.line = [NetworkHelper makeModelValueWithKey:@"is_line" Model:dic Null:@""];
//            model.idString = [NetworkHelper makeModelValueWithKey:@"line_id" Model:dic Null:@""];
//            
//            model.start_province = [NetworkHelper makeModelValueWithKey:@"start_province" Model:dic Null:@""];
//            model.start_city = [NetworkHelper makeModelValueWithKey:@"start_city" Model:dic Null:@""];
//            model.start_county = [NetworkHelper makeModelValueWithKey:@"start_county" Model:dic Null:@""];
//            
//            
//            model.end_province = [NetworkHelper makeModelValueWithKey:@"end_province" Model:dic Null:@""];
//            model.end_city = [NetworkHelper makeModelValueWithKey:@"end_city" Model:dic Null:@""];
//            model.end_county = [NetworkHelper makeModelValueWithKey:@"end_county" Model:dic Null:@""];
//            
//            
//            //            NSArray *array = [NetworkHelper makeModelValueWithKey:@"transports" Model:dic Null:@""];
//            //            model.transports = [NSMutableArray array];
//            //            for (NSDictionary *dic in array) {
//            //                transportsModel *traModel = [[transportsModel alloc] init];
//            //
//            //                traModel.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            //                traModel.trans_no = [NetworkHelper makeModelValueWithKey:@"trans_no" Model:dic Null:@""];
//            //                traModel.trans_status = [NetworkHelper makeModelValueWithKey:@"trans_status" Model:dic Null:@""];
//            //
//            //                traModel.driver_name = [NetworkHelper makeModelValueWithKey:@"driver_name" Model:dic Null:@""];
//            //
//            //                traModel.driver_phone = [NetworkHelper makeModelValueWithKey:@"driver_phone" Model:dic Null:@""];
//            //
//            //                traModel.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            //                traModel.bc_no = [NetworkHelper makeModelValueWithKey:@"bc_no" Model:dic Null:@""];
//            //                traModel.bc_bank_of_deposit = [NetworkHelper makeModelValueWithKey:@"bc_bank_of_deposit" Model:dic Null:@""];
//            //                traModel.card_owner = [NetworkHelper makeModelValueWithKey:@"card_owner" Model:dic Null:@""];
//            //
//            //                [model.transports addObject:traModel];
//            //            }
//            
//            return model;
//        }
//            break;
//        case ApiEnumCompleteTrans://确认运单完成
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//        }
//            break;
//        case ApiEnumCancelOrder://取消货源
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//        }
//            break;
//            
//        case ApiEnumFixDriver://确认司机抢单
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//        }
//            break;
//            
//        case ApiEnumGetRedPointOrderList://货源列表红点
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            getRedPointOrderListModel *model = [[getRedPointOrderListModel alloc] init];
//            model.uncheck = [NetworkHelper makeModelValueWithKey:@"uncheck" Model:dic Null:@""];
//            model.transporting = [NetworkHelper makeModelValueWithKey:@"transporting" Model:dic Null:@""];
//            return model;
//            
//        }
//            break;
//            
//        case ApiEnumGetGrabbedList://获取抢单列表
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            getGrabbedListModel *model = [[getGrabbedListModel alloc] init];
//            model.tid = [NetworkHelper makeModelValueWithKey:@"tid" Model:dic Null:@""];
//            model.driver_id = [NetworkHelper makeModelValueWithKey:@"driver_id" Model:dic Null:@""];
//            model.truck_id = [NetworkHelper makeModelValueWithKey:@"truck_id" Model:dic Null:@""];
//            model.real_name = [NetworkHelper makeModelValueWithKey:@"real_name" Model:dic Null:@""];
//            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            model.ceil_phone = [NetworkHelper makeModelValueWithKey:@"ceil_phone" Model:dic Null:@""];
//            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            model.avatar = [NSString stringWithFormat:@"%@%@", url,[NetworkHelper makeModelValueWithKey:@"avatar" Model:dic Null:@""]];
//            model.trans_status = [NetworkHelper makeModelValueWithKey:@"trans_status" Model:dic Null:@""];
//            return model;
//            
//        }
//            break;
//            
//        case ApiEnumGetTransList://获取运单列表
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            getTransListModel *model = [[getTransListModel alloc] init];
//            model.trans_id = [NetworkHelper makeModelValueWithKey:@"trans_id" Model:dic Null:@""];
//            model.driver_id = [NetworkHelper makeModelValueWithKey:@"driver_id" Model:dic Null:@""];
//            model.truck_id = [NetworkHelper makeModelValueWithKey:@"truck_id" Model:dic Null:@""];
//            model.realname = [NetworkHelper makeModelValueWithKey:@"realname" Model:dic Null:@""];
//            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            model.ceil_phone = [NetworkHelper makeModelValueWithKey:@"ceil_phone" Model:dic Null:@""];
//            model.create_time = [NetworkHelper makeModelValueWithKey:@"create_time" Model:dic Null:@""];
//            model.avatar = [NSString stringWithFormat:@"%@%@", url,[NetworkHelper makeModelValueWithKey:@"avatar" Model:dic Null:@""]];
//            model.trans_no = [NetworkHelper makeModelValueWithKey:@"trans_no" Model:dic Null:@""];
//            model.trans_status = [NetworkHelper makeModelValueWithKey:@"trans_status" Model:dic Null:@""];
//            model.bc_no = [NetworkHelper makeModelValueWithKey:@"bc_no" Model:dic Null:@""];
//            model.card_owner = [NetworkHelper makeModelValueWithKey:@"card_owner" Model:dic Null:@""];
//            model.bc_bank_of_deposit = [NetworkHelper makeModelValueWithKey:@"bc_bank_of_deposit" Model:dic Null:@""];
//            return model;
//            
//        }
//            break;
//        case ApiEnumGetTransPhoto://获取单据
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            getTransPhotoModel *model = [[getTransPhotoModel alloc] init];
//            model.idString = [NetworkHelper makeModelValueWithKey:@"id" Model:dic Null:@""];
//            model.photo_path = [NSString stringWithFormat:@"%@%@", url,[NetworkHelper makeModelValueWithKey:@"photo_path" Model:dic Null:@""]];
//            
//            return model;
//            
//        }
//            break;
//            
//        case ApiEnumUploadTransPhoto://上传单据
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            uploadTransPhotoModel *model = [[uploadTransPhotoModel alloc] init];
//            model.idString = [NetworkHelper makeModelValueWithKey:@"id" Model:dic Null:@""];
//            model.photo_path = [NSString stringWithFormat:@"%@%@", url,[NetworkHelper makeModelValueWithKey:@"photo_path" Model:dic Null:@""]];
//            
//            return model;
//            
//        }
//            break;
//            
//        case ApiEnumCancelGrab://取消已抢的单
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//        }
//            break;
//            
//            
//            
//            
//        case ApiEnumAddEleBill://添加电子提煤单
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            addEleBillModel *model = [[addEleBillModel alloc] init];
//            model.eb_id = [NetworkHelper makeModelValueWithKey:@"eb_id" Model:dic Null:@""];
//            return model;
//        }
//            break;
//            
//        case ApiEnumEleBillList://电子提煤单列表
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            EleBillListModel *model = [[EleBillListModel alloc] init];
//            model.eb_id = [NetworkHelper makeModelValueWithKey:@"eb_id" Model:dic Null:@""];
//            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            model.ceil_phone = [NetworkHelper makeModelValueWithKey:@"ceil_phone" Model:dic Null:@""];
//            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            model.done_time = [NetworkHelper makeModelValueWithKey:@"done_time" Model:dic Null:@""];
//            model.settled_time = [NetworkHelper makeModelValueWithKey:@"settled_time" Model:dic Null:@""];
//            model.trans_time = [NetworkHelper makeModelValueWithKey:@"trans_time" Model:dic Null:@""];
//            
//            return model;
//        }
//            break;
//            
//        case ApiEnumEleBillInfo://电子提煤单详情
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            EleBillInfo *model = [[EleBillInfo alloc] init];
//            model.realname = [NetworkHelper makeModelValueWithKey:@"realname" Model:dic Null:@""];
//            model.plate_no = [NetworkHelper makeModelValueWithKey:@"plate_no" Model:dic Null:@""];
//            model.ceil_phone = [NetworkHelper makeModelValueWithKey:@"ceil_phone" Model:dic Null:@""];
//            model.add_time = [NetworkHelper makeModelValueWithKey:@"add_time" Model:dic Null:@""];
//            model.done_time = [NetworkHelper makeModelValueWithKey:@"done_time" Model:dic Null:@""];
//            model.settled_time = [NetworkHelper makeModelValueWithKey:@"settled_time" Model:dic Null:@""];
//            
//            
//            model.origin_weight = [NetworkHelper makeModelValueWithKey:@"origin_weight" Model:dic Null:@""];
//            model.freight = [NetworkHelper makeModelValueWithKey:@"freight" Model:dic Null:@""];
//            model.receive_weight = [NetworkHelper makeModelValueWithKey:@"receive_weight" Model:dic Null:@""];
//            model.coal_name = [NetworkHelper makeModelValueWithKey:@"coal_name" Model:dic Null:@""];
//            
//            model.total_loss = [NetworkHelper makeModelValueWithKey:@"total_loss" Model:dic Null:@""];
//            model.e_status = [NetworkHelper makeModelValueWithKey:@"e_status" Model:dic Null:@""];
//            model.note = [NetworkHelper makeModelValueWithKey:@"note" Model:dic Null:@""];
//            
//            
//            model.load_addr = [NetworkHelper makeModelValueWithKey:@"load_addr" Model:dic Null:@""];
//            model.unload_addr = [NetworkHelper makeModelValueWithKey:@"unload_addr" Model:dic Null:@""];
//            model.top_service = [NetworkHelper makeModelValueWithKey:@"top_service" Model:dic Null:@""];
//            model.bottom_service = [NetworkHelper makeModelValueWithKey:@"bottom_service" Model:dic Null:@""];
//
//            
//            
//            
//            NSArray *photos_out = [NetworkHelper makeModelValueWithKey:@"photos_out" Model:dic Null:[NSMutableArray array]];
//            
//            model.photos_out = [NSMutableArray array];
//            
//                for (NSDictionary *dic in photos_out) {
//                    billPhoto_outModel *outModel = [[billPhoto_outModel alloc] init];
//                    outModel.p_id = [NetworkHelper makeModelValueWithKey:@"p_id" Model:dic Null:@""];
//                    outModel.p_path = [NSString stringWithFormat:@"%@%@", url,[NetworkHelper makeModelValueWithKey:@"p_path" Model:dic Null:@""]];
//                    
//                    [model.photos_out addObject:outModel];
//                }
//                
//        
//            
//            NSArray *photos_in = [NetworkHelper makeModelValueWithKey:@"photos_in" Model:dic Null:[NSMutableArray array]];
//            model.photos_in = [NSMutableArray array];
//            
//            for (NSDictionary *dic in photos_in) {
//                    billPhoto_inModel *inModel = [[billPhoto_inModel alloc] init];
//                    inModel.p_id = [NetworkHelper makeModelValueWithKey:@"p_id" Model:dic Null:@""];
//                    inModel.p_path = [NSString stringWithFormat:@"%@%@", url,[NetworkHelper makeModelValueWithKey:@"p_path" Model:dic Null:@""]];
//                    [model.photos_in addObject:inModel];
//            }
//            
//            
//            
//            
//            return model;
//        }
//            break;
//            
//            
//            
//        case ApiEnumDoneEleBill://完成电子提煤单
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//            
//        }
//            break;
//            
//        case ApiEnumUploadPhoto://上传图片
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            uploadPhotoModel *model = [[uploadPhotoModel alloc] init];
//            model.p_path = [NetworkHelper makeModelValueWithKey:@"p_path" Model:dic Null:@""];
//            model.p_id = [NetworkHelper makeModelValueWithKey:@"p_id" Model:dic Null:@""];
//            
//            return model;
//            
//        }
//            break;
//            
//        case ApiEnumDeletePhoto://删除图片
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//            
//        }
//            break;
//            
//        case ApiEnumSaveNotes://保存备注
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//            
//        }
//            break;
//           
//        case ApiEnumDelEleBill://删除电子提煤单
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//            
//        }
//            break;
//            
//        case ApiEnumTransEleBill://上游完成-运输中
//        {
//            NSDictionary *dic = (NSDictionary *)modelObj;
//            return dic;
//            
//        }
//            break;
//   
//            
//            
//        default:
//        {
//            return nil;
//        }
//            break;
//    }
//}
//
@end
